package net.mz.callflakessdk.core;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import net.mz.callflakessdk.R;
import net.mz.callflakessdk.libcfint.BannerDownloadListener;
import net.mz.callflakessdk.libcfint.CFLib;

import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ContentUris;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.ContactsContract;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.localytics.android.LocalyticsSession;


/**
 * Activity to display the PostCallManager SDK Call Terminate screen.
 * </br>
 * This is the focal point of the PostCallManager SDK.
 * <p>
 * Note: this is not a public API.
 */
public class ActivityCallTerminate extends Activity implements EmailSelectListener, BannerDownloadListener
{
	private LocalyticsSession localyticsSession;  // Analytics
	
	public static PostCallManager postCallManager = null;  // PostCallManager instance used for setting/getting configuration and contact details
	private ReceiverCallEvents receiverCallEvents = null;  // Broadcast Receiver used for closing the screen 

	private String phoneNumber = null;  // Contact phone number, passed through an intent from ReceiverCall
	private PhoneContact phoneContact = null;   // Contact retrieved based on phoneNumber

	private Handler hndAutoComplete = null;  // Handler which triggers requests for Google auto-complete suggestions
	private long lastAutoCompleteRequestTime = 0;  // Timestamp of the last auto-complete request. Used to introduce a delay between requests.
	
	private Handler handlerAutoHideScreen = null;  // Handler used for automatically closing the Call Terminate screen
	private Runnable runnableAutoHideScreen;
	
	// Views
	private AutoCompleteTextView txtWebSearch = null;
	private AsyncTaskAutoComplete taskAutoComplete = null;
	private RelativeLayout rlCallTerminate = null;
	private RelativeLayout rlCallTerminateChild = null;
	private LinearLayout llWebSearchShadow = null;
	private RelativeLayout llCallTerminateWebSearch = null;
	private ImageView imgClose = null;
	private TextView txtPowered = null;
	private LinearLayout llDisableSmartCallConfirm = null;
	private Button btnDisableSmartCallYes = null;
	private Button btnDisableSmartCallNo = null;
	private ToggleButton btnDisableSmartCall = null;
	private Button btnRewards = null;
	private LinearLayout llUserPhoto = null;
	private ImageView imgUserPhoto = null;
	private LinearLayout imgAddContact = null;
	private LinearLayout llUserPhotoViewContact = null;
//	private TextView txtUserPhotoViewContact = null;
//	private View viewContactSeparator = null;
	private TextView txtTime = null;

	private TextView txtUserName = null;
//	@SuppressWarnings("unused")
//	private TextView txtFollowUpCall = null;

	private Button btnText = null;
	private Button btnEmail = null;
	private Button btnMeeting = null;
	private Button btnCall = null;

	private LinearLayout llAds = null;
	private boolean isRedirect = false;

	
	// Contact image click
	OnClickListener clickListenerUserPhoto = new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			showContactInfo();
		}
	};

	
	// Close button click
	OnClickListener clickListenerClose = new OnClickListener()
	{

		@Override
		public void onClick(View v)
		{
			closeScreen();
		}
	};


	// "Powered by ..." click
	OnClickListener clickListenerTxtPowered = new OnClickListener()
	{

		@Override
		public void onClick(View v)
		{
			launchMainApp();
		}
	}; 
	
	
	// Disable Smart Call toggle button click
	OnClickListener clickListenerDisableSmartCall = new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			localyticsSession.tagEvent("Call Terminate - Remove");
			llDisableSmartCallConfirm.setVisibility(View.VISIBLE);
		}
	};
	
	
	// Disable Smart Call YES button click
	OnClickListener clickListenerDisableSmartCallYes = new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			localyticsSession.tagEvent("Call Terminate - Remove confirmation-Yes");
			CFLib.loadAdBannerStartApp2(postCallManager.getDisableUrl(), null);  // Sorry for the misleading method name. This does not actually download a banner. It just performs a request without waiting for a response from the server.
			postCallManager.setEnablePostCallScreen(false);
			cancelAutoHideScreen();
			finish();
		}
	};
	
	
	// Disable Smart Call NO button click
	OnClickListener clickListenerDisableSmartCallNo = new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			localyticsSession.tagEvent("Call Terminate - Remove confirmation-No");
			btnDisableSmartCall.setChecked(true);
			llDisableSmartCallConfirm.setVisibility(View.GONE);
		}
	};
	
	
	// Free Apps button click
	OnClickListener clickListenerRewards = new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			showRewards();
		}
	};
	
	
	// Add Contact button click
	OnClickListener clickListenerAddContact = new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			showContactInfo();
		}
	};
	
	
	// Text button click
	OnClickListener clickListenerText = new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			btnText.setEnabled(false);
			sendSMS();
			reEnableActionButtons();
		}
	};
	
	
	// Email button click
	OnClickListener clickListenerEmail = new OnClickListener()
	{

		@Override
		public void onClick(View v)
		{
			btnEmail.setEnabled(false);
			sendEmail();
			reEnableActionButtons();
		}
	};
	
	
	// Meeting button click
	OnClickListener clickListenerMeeting = new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			btnMeeting.setEnabled(false);
			setMeeting();
			reEnableActionButtons();
		}
	};
	
	
	// Call button click
	OnClickListener clickListenerCall = new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			btnCall.setEnabled(false);
			callContact();
			reEnableActionButtons();
		}
	};
	
	
	// StartApp ad banner click
	OnClickListener clAdBanner = new OnClickListener()
	{
		public void onClick(View v)
		{
			cancelAutoHideScreen();
			localyticsSession.tagEvent("Call Terminate - Ad banner");
			CFFunctions.logD(CFConstants.TAG, "ActivityCallTerminate -> StartApp banner click");
		};
	};

//	AdListener adMobListener = new AdListener()
//	{
//		  public void onReceiveAd(Ad ad)
//		  {
//			  CFFunctions.logD(CFConstants.TAG, "ActivityCallTerminate -> AdMob onReceivedAd");
//		  }
//		  
//		  public void onFailedToReceiveAd(Ad ad, AdRequest.ErrorCode error)
//		  {
//			  CFFunctions.logD(CFConstants.TAG, "ActivityCallTerminate -> AdMob onFailedToReceiveAd");
//		  }
//		  
//		  public void onPresentScreen(Ad ad)
//		  {
//			  CFFunctions.logD(CFConstants.TAG, "ActivityCallTerminate -> AdMob onPresentScreen");
//			  
//			  cancelAutoHideScreen();
//			  localyticsSession.tagEvent("Call Terminate - AdMob banner");
//			  CFFunctions.logD(CFConstants.TAG, "ActivityCallTerminate -> AdMob banner click");							  
//		  }
//		  
//		  public void onDismissScreen(Ad ad)
//		  {
//			  CFFunctions.logD(CFConstants.TAG, "ActivityCallTerminate -> AdMob onDismissScreen");
//		  }
//		  
//		  public void onLeaveApplication(Ad ad)
//		  {
//			  CFFunctions.logD(CFConstants.TAG, "ActivityCallTerminate -> AdMob onLeaveApplication");
//		  }
//	};
	
	// Web search - suggestions click
	OnItemClickListener itemClickWebSearch = new OnItemClickListener()
	{
		public void onItemClick(AdapterView<?> adapterView, final View view, int position, long id)
		{
			try
			{
				if (taskAutoComplete != null)
				{
					taskAutoComplete.cancel(true);
				}
			}
			catch (Exception e)
			{
			}
			txtWebSearch.removeTextChangedListener(textWatcherWebSearch);
			
			String clickedString = (String) txtWebSearch.getAdapter().getItem(position);
			txtWebSearch.setText(clickedString);
			txtWebSearch.dismissDropDown();
			CFFunctions.hideSoftKeyboard(ActivityCallTerminate.this, getWindow().getDecorView().getWindowToken());
			webSearch(clickedString);
			
			txtWebSearch.addTextChangedListener(textWatcherWebSearch);
		};
	};
	
	
	// Web Search - soft keyboard Search icon click
	OnEditorActionListener editorActionListenerWebSearch = new OnEditorActionListener()
	{
		@Override
		public boolean onEditorAction(TextView v, int actionId, KeyEvent event)
		{
			if (actionId == EditorInfo.IME_ACTION_SEARCH)
			{
//				txtWebSearch.dismissDropDown();
//				CFFunctions.hideSoftKeyboard(ActivityCallTerminate.this, getWindow().getDecorView().getWindowToken());
//				webSearch(txtWebSearch.getText().toString());
				
				cancelAutoHideScreen();
				webSearch(txtWebSearch.getText().toString());
			}
			return false;
		}
	}; 
		
	private OnClickListener imgWebSearchClickListener = new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			cancelAutoHideScreen();
			webSearch(txtWebSearch.getText().toString());
		}
	};
	
	// Web Search - receive focus
	OnFocusChangeListener focusChangeListenerWebSearch = new OnFocusChangeListener()
	{
		public void onFocusChange(View v, boolean hasFocus)
		{
			if (hasFocus)
			{
				localyticsSession.tagEvent("Call Terminate - Search Focused");
				
				// cancel auto hide screen if the user searches
				handlerAutoHideScreen.removeCallbacks(runnableAutoHideScreen);
			}
		}
	};
	
	
	// Web Search - click event
	OnClickListener clWebSearch = new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
//			cancelAutoHideScreen();
//			webSearch("");
		}
	};

	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);

		setContentView(R.layout.activity_call_terminate);
		
		// Create PostCallManager instance
		postCallManager = new PostCallManager(this);
		
		// Get data from the intent used to launch this activity
		CFFunctions.logD(CFConstants.TAG, "ActivityCallTerminate.onCreate -> Processing intent...");
		processIntent();
		
		// Get views and set events for them
//		viewContactSeparator = findViewById(R.id.viewContactSeparator);
//		txtFollowUpCall = (TextView) findViewById(R.id.txtFollowUpCall);
		txtUserName = (TextView) findViewById(R.id.txtUserName);
		llDisableSmartCallConfirm = (LinearLayout) findViewById(R.id.llDisableSmartCallConfirm);
		llCallTerminateWebSearch = (RelativeLayout) findViewById(R.id.llCallTerminateWebSearch);
		llWebSearchShadow = (LinearLayout) findViewById(R.id.llWebSearchShadow);
		txtWebSearch = (AutoCompleteTextView) findViewById(R.id.txtWebSearch);
		if (txtWebSearch != null)
		{
//			txtWebSearch.setKeyListener(null);
//			txtWebSearch.setOnClickListener(clWebSearch);
//			
//			txtWebSearch.addTextChangedListener(textWatcherWebSearch);
//			txtWebSearch.setOnItemClickListener(itemClickWebSearch);
//			txtWebSearch.setOnEditorActionListener(editorActionListenerWebSearch);
			txtWebSearch.setOnFocusChangeListener(focusChangeListenerWebSearch);
		}
		
		// Web Search - drawable click
		txtWebSearch.setOnTouchListener(new DrawableOnTouchListener(txtWebSearch)
		{

			@Override
			public boolean onDrawableTouch(final MotionEvent event)
			{
				event.setAction(MotionEvent.ACTION_CANCEL);
				if ((txtWebSearch.getText().toString() != null) && ((txtWebSearch.getText().toString().length() > 0)))
				{
					txtWebSearch.dismissDropDown();
					CFFunctions.hideSoftKeyboard(ActivityCallTerminate.this, getWindow().getDecorView().getWindowToken());

					webSearch(txtWebSearch.getText().toString());
				}
				return true;
			}
		});
		
		txtWebSearch.setOnEditorActionListener(editorActionListenerWebSearch);
		
		ImageView imgWebSearch = (ImageView) findViewById(R.id.imgSearchIcon);
		imgWebSearch.setOnClickListener(imgWebSearchClickListener);

		rlCallTerminate = (RelativeLayout) findViewById(R.id.rlCallTerminate);
		rlCallTerminateChild = (RelativeLayout) findViewById(R.id.rlCallTerminateChild);
//		final View lRlCallTerminate = rlCallTerminate;
//		
//		// Detect layout resize due to soft keyboard display. Needed for web search auto-complete.
//		lRlCallTerminate.getViewTreeObserver().addOnGlobalLayoutListener(new OnGlobalLayoutListener()
//		{
//		    @Override
//		    public void onGlobalLayout()
//		    {		        
//		        // The line below works only with windowSoftInputMode = adjustResize
//		        // int heightDiff = lRlCallTerminate.getRootView().getHeight() - lRlCallTerminate.getHeight();
//		        
//		    	// The below code works with windowSoftInputMode = adjustPan
//		    	Rect r = new Rect();
//		    	lRlCallTerminate.getWindowVisibleDisplayFrame(r);
//		        int heightDiff = lRlCallTerminate.getRootView().getHeight() - (r.bottom - r.top);
//		        
//		        int marginWidth = (int) (getResources().getDisplayMetrics().density * 20);
//		        CFFunctions.logD(CFConstants.TAG, "ActivityCallTerminate.onGlobalLayout -> heightDiff: " + heightDiff);
//		        
//		        // If more than 150 pixels, it's probably a keyboard...
//		        if ((!isKeyboardVisible) && (heightDiff > 150))
//		        {
//		        	isKeyboardVisible = true;
//		        	
//		        	// New layout params for llCallTerminateWebsearch
//		        	RelativeLayout.LayoutParams p = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
//		        	p.addRule(RelativeLayout.ALIGN_PARENT_TOP);
//		        	p.setMargins(marginWidth, marginWidth, marginWidth, (int) (marginWidth / 2));
//		        	llCallTerminateWebSearch.setLayoutParams(p);
//		        	
//		        	// New layout params for rlCallTerminateChild
//		        	RelativeLayout.LayoutParams p2 = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
//		        	p2.addRule(RelativeLayout.BELOW, R.id.llCallTerminateWebSearch);
//		        	rlCallTerminateChild.setLayoutParams(p2);
//		        	
//		        	llWebSearchShadow.setVisibility(View.VISIBLE);
//		        }
//
//		        if ((isKeyboardVisible) && (heightDiff < 150))
//		        {
//		        	isKeyboardVisible = false;
//		        	
//		        	llWebSearchShadow.setVisibility(View.GONE);
//		        	
//		        	// Original layout params for rlCallTerminateChild
//		        	RelativeLayout.LayoutParams p2 = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
//		        	p2.addRule(RelativeLayout.BELOW, 0);
//		        	rlCallTerminateChild.setLayoutParams(p2);
//
//		        	// Original layout params for Web Search
//		        	RelativeLayout.LayoutParams p = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
//		        	p.setMargins(marginWidth, (int) (marginWidth / 2), marginWidth, 0);
//		        	p.addRule(RelativeLayout.BELOW, R.id.rlCallTerminateChild);
//
//		        	llCallTerminateWebSearch.setLayoutParams(p);        	
//		        }
//		     }
//		});

		
		llAds = (LinearLayout) findViewById(R.id.llAds);
		// llAds.setOnClickListener(clAdBanner);
		showAds();

		imgClose = (ImageView) findViewById(R.id.imgClose);
		if (imgClose != null)
		{
			imgClose.setOnClickListener(clickListenerClose);
		}
		
		txtPowered = (TextView) findViewById(R.id.txtPowered);
		if (txtPowered != null)
		{
			txtPowered.setOnClickListener(clickListenerTxtPowered);
			
			if ((postCallManager.getAppName() != null) && (postCallManager.getAppName().length() > 0))
			{
				txtPowered.setText(String.format(getString(R.string.strPowered), postCallManager.getAppName()));
			}
			else
			{
				txtPowered.setText("");
			}
		}
		
		
		btnDisableSmartCall = (ToggleButton) findViewById(R.id.btnDisableSmartCall);
		if (btnDisableSmartCall != null)
		{
			btnDisableSmartCall.setChecked(postCallManager.isEnablePostCallScreen());
			btnDisableSmartCall.setOnClickListener(clickListenerDisableSmartCall);
		}

		btnDisableSmartCallYes = (Button) findViewById(R.id.btnDisableSmartCallYes);
		if (btnDisableSmartCallYes != null)
		{
			btnDisableSmartCallYes.setOnClickListener(clickListenerDisableSmartCallYes);
		}
		
		btnDisableSmartCallNo = (Button) findViewById(R.id.btnDisableSmartCallNo);
		if (btnDisableSmartCallNo != null)
		{
			btnDisableSmartCallNo.setOnClickListener(clickListenerDisableSmartCallNo);
		}
		
		btnRewards = (Button) findViewById(R.id.btnRewards);
		if (btnRewards != null)
		{
			btnRewards.setOnClickListener(clickListenerRewards);
		}

		llUserPhoto = (LinearLayout) findViewById(R.id.llUserPhoto);
		if (llUserPhoto != null)
		{
			llUserPhoto.setOnClickListener(clickListenerUserPhoto);
		}
		
		llUserPhotoViewContact = (LinearLayout) findViewById(R.id.llUserPhotoViewContact);
		if (llUserPhotoViewContact != null)
		{
			llUserPhotoViewContact.setOnClickListener(clickListenerUserPhoto);
		}
		
//		txtUserPhotoViewContact = (TextView) findViewById(R.id.txtUserPhotoViewContact);
//		if (txtUserPhotoViewContact != null)
//		{
//			txtUserPhotoViewContact.setOnClickListener(clickListenerUserPhoto);
//		}
		
		imgUserPhoto = (ImageView) findViewById(R.id.imgUserPhoto);
		if (imgUserPhoto != null)
		{
			imgUserPhoto.setOnClickListener(clickListenerUserPhoto);
		}

		imgAddContact = (LinearLayout) findViewById(R.id.imgAddContact);
		if (imgAddContact != null)
		{
			imgAddContact.setOnClickListener(clickListenerAddContact);
		}

		btnText = (Button) findViewById(R.id.btnText);
		if (btnText != null)
		{
			btnText.setOnClickListener(clickListenerText);
		}

		btnEmail = (Button) findViewById(R.id.btnEmail);
		if (btnEmail != null)
		{
			btnEmail.setOnClickListener(clickListenerEmail);
		}

		btnMeeting = (Button) findViewById(R.id.btnMeeting);
		if (btnMeeting != null)
		{
			btnMeeting.setOnClickListener(clickListenerMeeting);
		}

		btnCall = (Button) findViewById(R.id.btnCall);
		if (btnCall != null)
		{
			btnCall.setOnClickListener(clickListenerCall);
		}


		// Populate all required views with contact details
		fillContactDetailsViews();
		
		// Analytics
	    this.localyticsSession = CFLib.getLocalyticsSessionStartApp(this);
	 
	    this.localyticsSession.open();
	    this.localyticsSession.upload();
	    
		// Automatically close the screen after a given time period
		autoHideScreen();
	}

	
	@Override
	protected void onNewIntent(Intent intent)
	{
		super.onNewIntent(intent);
		
		CFFunctions.logD(CFConstants.TAG, "ActivityCallTerminate.onCreate -> Processing intent...");
		if (processIntent())
		{
			CFFunctions.logD(CFConstants.TAG, "ActivityCallTerminate.onCreate -> Intent processed successfully");
			fillContactDetailsViews();
		}
		else
		{
			CFFunctions.logD(CFConstants.TAG, "ActivityCallTerminate.onCreate -> Intent NOT processed successfully");
		}
	}

	@Override
	protected void onStart()
	{
		super.onStart();
	}


	@Override
	protected void onStop()
	{
		super.onStop();
		
		postCallManager.clearTempState();
	}


	@Override
	protected void onPause()
	{
		this.localyticsSession.close();
	    this.localyticsSession.upload();
	    
		super.onPause();		
	}


	@Override
	protected void onDestroy()
	{
		super.onDestroy();

		if (receiverCallEvents != null)
		{
			unregisterReceiver(receiverCallEvents);
		}
		
		// Revert evrything to original state 
		postCallManager.clearTempState();
		postCallManager.reEnableScreenPowerOff();
		postCallManager.reEnableScreenLock();
	}


	@Override
	protected void onResume()
	{
		super.onResume();

		this.localyticsSession.open();
		
		postCallManager.revertScreenStatus(false);
		reEnableActionButtons();

		// Register the receiver which will finish the activity when the call ends
		if (receiverCallEvents == null)
		{
			IntentFilter filterCallFinish = new IntentFilter(CFConstants.PHONE_CALL_FINISH_RECEIVER_NAME);
			receiverCallEvents = new ReceiverCallEvents();
			registerReceiver(receiverCallEvents, filterCallFinish);
		}
		
		ArrayAdapter<String> adapter = null;
		txtWebSearch.setAdapter(adapter);
		
		CFFunctions.hideSoftKeyboard(this, getWindow().getDecorView().getWindowToken());
		
//		showBanner(null);
	}


	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		super.onActivityResult(requestCode, resultCode, data);

		switch (requestCode)
		{
		// A contact has been picked. Start the Contacts app activity for editing contact details.
		case CFConstants.REQUEST_CODE_PICK_CONTACT:
			if (resultCode == Activity.RESULT_OK)
			{
				Cursor cursorContacts = null;
				try
				{
					Uri contactData = data.getData();
					cursorContacts = managedQuery(contactData, null, null, null, null);
					if (cursorContacts.moveToFirst())
					{
						long idContact = cursorContacts.getLong(cursorContacts.getColumnIndex(ContactsContract.Contacts._ID));

						Uri uri = ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, idContact);
						Intent intent = new Intent(Intent.ACTION_EDIT, uri);
						intent.putExtra(ContactsContract.Intents.Insert.PHONE, phoneNumber);
						intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
						
						PackageManager pm = getPackageManager();
						if (pm.resolveActivity(intent, 0) != null)
						{
							startActivity(intent);
						}
					}
				}
				catch (Exception e)
				{
					if (cursorContacts != null)
					{
						cursorContacts.close();
					}
				}
				finally
				{
					if (cursorContacts != null)
					{
						cursorContacts.close();
					}
				}
			}
			break;
			
		case CFConstants.REQUEST_CODE_SEND_EMAIL:
			// hide soft keyboard when the email was sent
			getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
			break;
		}
	}


	@Override
	public void onEmailSelected(String emailAddress)
	{
		String emailBody = null;

		// An email address has been selected. Start email client with pre-populated data for sending an email.
		cancelAutoHideScreen();
		if (!CFFunctions.sendEmail(this, getResources().getString(R.string.strEmailSubjectAfterCall), emailAddress, emailBody))
		{
			Toast.makeText(this, getResources().getString(R.string.msgNoEmailClient), Toast.LENGTH_SHORT).show();
		}
	}


	// Processes the intent used to launch the activity
	private boolean processIntent()
	{
		CFFunctions.logD(CFConstants.TAG, "ActivityCallTerminate.processIntent -> BEGIN");
		
		// Get phone number that is calling
		Intent intent = getIntent();
		CFFunctions.logD(CFConstants.TAG, "ActivityCallTerminate.processIntent -> intent: " + intent);
		CFFunctions.logD(CFConstants.TAG, "ActivityCallTerminate.processIntent -> intent.hasExtra(CFConstants.INTENT_KEY_PHONE_NUMBER): " + intent.hasExtra(CFConstants.INTENT_KEY_PHONE_NUMBER));
		if (intent.hasExtra(CFConstants.INTENT_KEY_PHONE_NUMBER))
		{
			try
			{
				phoneNumber = intent.getStringExtra(CFConstants.INTENT_KEY_PHONE_NUMBER);
				CFFunctions.logD(CFConstants.TAG, "ActivityCallTerminate.onCreate -> Intent - phoneNumber: " + phoneNumber);
	
				// Get phone contact and FB user
				phoneContact = null;
	
				long idPhoneContact = 0;
				phoneContact = PhoneContactsList.getContactWithPhoneNumber(this, phoneNumber);
				if (phoneContact != null)
				{
					idPhoneContact = phoneContact.getId();
					CFFunctions.logD(CFConstants.TAG, "ActivityCallTerminate.processIntent -> Found contact, ID is: " + idPhoneContact);
				}
	
				if (phoneContact == null)
				{
					CFFunctions.logD(CFConstants.TAG, "ActivityCallTerminate.processIntent -> Contact not found, perfroming additional search");
					phoneContact = postCallManager.getTempPhoneContact(phoneNumber);
					if (phoneContact != null)
					{
						idPhoneContact = phoneContact.getId();
						CFFunctions.logD(CFConstants.TAG, "ActivityCallTerminate.processIntent -> Found contact on additional search, ID is: " + idPhoneContact);
					}
				}
				CFFunctions.logD(CFConstants.TAG, "ActivityCallTerminate.onCreate -> idPhoneContact: " + idPhoneContact);
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
			
			return true;
		}
		
		return false;
	}
	
	
	// Populates views with contact details
	private void fillContactDetailsViews()
	{
		Bitmap contactPhoto = null;
		
		txtTime = (TextView) findViewById(R.id.txtTime);
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm");
		String formattedDate = dateFormat.format(calendar.getTime());
		txtTime.setText(formattedDate);
		
		if ((phoneContact != null) && (phoneContact.getName() != null) && (phoneContact.getName().length() > 0))
		{
			llUserPhoto.setVisibility(View.VISIBLE);
			imgAddContact.setVisibility(View.INVISIBLE);
			contactPhoto = PhoneContactsList.loadContactPhoto(this, phoneContact.getId());
			imgUserPhoto.setImageBitmap(contactPhoto);  // photo memory
			txtUserName.setText(phoneContact.getName());
		}
		else
		{
			if ((phoneNumber != null) && (phoneNumber.length() > 0))
			{
				llUserPhoto.setVisibility(View.INVISIBLE);
				llUserPhotoViewContact.setBackgroundDrawable(null);
//				txtUserPhotoViewContact.setVisibility(View.GONE);
//				viewContactSeparator.setVisibility(View.GONE);
				imgAddContact.setVisibility(View.VISIBLE);
				txtUserName.setText(phoneNumber);
			}
			else
			{
				llUserPhoto.setVisibility(View.VISIBLE);
				imgAddContact.setVisibility(View.INVISIBLE);
				imgUserPhoto.setImageBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.ic_add_to_contact));
				txtUserName.setText(getResources().getString(R.string.strUnknown));
			}
		}
	}


	// Adds a new contact in the Contacts database or displays contact details
	private void showContactInfo()
	{
		localyticsSession.tagEvent("Call Terminate - View contact");
		
		// Contact has been found based on phoneNumber. View it.
		if (phoneContact != null)
		{
			try
			{
				cancelAutoHideScreen();
				Intent intent = new Intent(Intent.ACTION_VIEW);
				Uri uri = Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_URI, String.valueOf(phoneContact.getId()));
				intent.setData(uri);
				intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
				PackageManager pm = getPackageManager();
				if (pm.resolveActivity(intent, 0) != null)
				{
					startActivity(intent);
				}
			}
			catch (Exception e)
			{
			}
		}
		else
		{
			// If we have a phone number
			if ((phoneNumber != null) && (phoneNumber.length() > 0))
			{
				// If the Contacts database has at least one contact...
				// Display a dialog which allows the user to choose between adding a new contact or pick an existing contact to edit.
				if (PhoneContactsList.getContactsCount(this) > 0)
				{
					// Prepare and show the dialog
					final CharSequence[] contactActions = new CharSequence[2];
					contactActions[0] = getString(R.string.strAddNewContact);
					contactActions[1] = getString(R.string.strUpdateContact);
					AlertDialog.Builder builder = new AlertDialog.Builder(this);
					builder.setTitle(getResources().getString(R.string.strChooseAction));
					
					builder.setItems(contactActions, new DialogInterface.OnClickListener()
					{

						public void onClick(DialogInterface dialog, int item)
						{
							PackageManager pm = getPackageManager();
							switch (item)
								{
								// Add a new contact 
								case 0:
									cancelAutoHideScreen();
									Intent intentAddContact = new Intent(Intent.ACTION_INSERT, ContactsContract.Contacts.CONTENT_URI);
									intentAddContact.putExtra(ContactsContract.Intents.Insert.PHONE, phoneNumber);
									intentAddContact.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
									if (pm.resolveActivity(intentAddContact, 0) != null)
									{
										startActivity(intentAddContact);
									}
									break;
								
								// Pick existing contact
								case 1:
									cancelAutoHideScreen();
									Intent intentSelectContact = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
									intentSelectContact.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
									if (pm.resolveActivity(intentSelectContact, 0) != null)
									{
										startActivityForResult(intentSelectContact, CFConstants.REQUEST_CODE_PICK_CONTACT);
									}
									break;
									
								default:
									break;
								}
							dialog.dismiss();
						}
					});
					
					try
					{
						AlertDialog alert = builder.create();
						alert.show();
					}
					catch (Exception e)
					{
						e.printStackTrace();
					}
				}
				else
				// The Contacts database contains no contacts. Insert one.
				{
					Intent intent = new Intent(Intent.ACTION_INSERT, ContactsContract.Contacts.CONTENT_URI);
					intent.putExtra(ContactsContract.Intents.Insert.PHONE, phoneNumber);
					intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
					PackageManager pm = getPackageManager();
					if (pm.resolveActivity(intent, 0) != null)
					{
						startActivity(intent);
					}
				}
			}
		}
	}


	private void closeScreen()
	{
		cancelAutoHideScreen();
		finish();
		sendAppToBackground();
	}


	// Display Free Apps
	private void showRewards()
	{
		this.localyticsSession.tagEvent("Call Terminate - Free Apps");

		if (!CFFunctions.isInternetConnected(this))
		{
			Toast.makeText(this, getString(R.string.strNoInternet), Toast.LENGTH_SHORT).show();
			return;
		}

		cancelAutoHideScreen();
		CFFunctions.hideSoftKeyboard(ActivityCallTerminate.this, getWindow().getDecorView().getWindowToken());

		Intent adsScreen = new Intent(this, ActivityAds.class);
		adsScreen.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
		PackageManager pm = getPackageManager();
		if (pm.resolveActivity(adsScreen, 0) != null)
		{
			startActivity(adsScreen);
		}
	}


	// Send SMS back to the contact
	private void sendSMS()
	{
		this.localyticsSession.tagEvent("Call Terminate - Message");
			
		if ((phoneNumber != null) && (phoneNumber.length() > 0))
		{
			cancelAutoHideScreen();
			CFFunctions.hideSoftKeyboard(ActivityCallTerminate.this, getWindow().getDecorView().getWindowToken());
			
			// Start Activity for sending SMS 
			// Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("sms:" + phoneNumber));
			Uri uri = Uri.parse("smsto:" + phoneNumber) ;
			Intent intent = new Intent(Intent.ACTION_SENDTO, uri);
			intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
			PackageManager pm = getPackageManager();
			if (pm.resolveActivity(intent, 0) != null)
			{
				startActivity(Intent.createChooser(intent, getString(R.string.strSMSChooserTitle)));
			}
		}
	}


	// Send call follow-up email
	private void sendEmail()
	{
		this.localyticsSession.tagEvent("Call Terminate - Email");

		if (phoneContact != null)
		{
			postCallManager.chooseEmail(this, phoneContact.getId(), this);
		}
		else
		{
			String emailBody = null;

			cancelAutoHideScreen();
			if (!CFFunctions.sendEmail(this, getResources().getString(R.string.strEmailSubjectAfterCall), null, emailBody))
			{
				Toast.makeText(this, getResources().getString(R.string.msgNoEmailClient), Toast.LENGTH_SHORT).show();
			}
		}
	}


	// Set meeting after a call
	private void setMeeting()
	{
		this.localyticsSession.tagEvent("Call Terminate - Calendar");

		String title;
		if ((phoneContact != null) && (phoneContact.getName() != null) && (phoneContact.getName().length() > 0))
		{
			title = phoneContact.getName();
		}
		else
		{
			if ((phoneNumber != null) && (phoneNumber.length() > 0))
			{
				title = phoneNumber;
			}
			else
				title = "";
		}

		cancelAutoHideScreen();
		if (!CFFunctions.setCalendarEvent(this, title, System.currentTimeMillis(), System.currentTimeMillis()))
		{
			Toast.makeText(this, getResources().getString(R.string.msgNoCalendar), Toast.LENGTH_SHORT).show();
		}
	}


	// Call back contact
	private void callContact()
	{
		this.localyticsSession.tagEvent("Call Terminate - Call");

		if ((phoneNumber != null) && (phoneNumber.length() > 0))
		{
			try
			{
				cancelAutoHideScreen();
				CFFunctions.logD(CFConstants.TAG, "ActivityCallTerminate.callContact -> Start calling");
				postCallManager.handlePhoneCall(this, CFConstants.CALL_ACTION_CALL, 0, phoneNumber);
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
	}


	// Start web search
	private void webSearch(String searchQuery)
	{
		this.localyticsSession.tagEvent("Call Terminate - Search Start");
		
		cancelAutoHideScreen();
		
		List<NameValuePair> pairs = new ArrayList<NameValuePair>();
		pairs.add(new BasicNameValuePair("q", searchQuery));
		String paramQuery = URLEncodedUtils.format(pairs, "utf-8");
		if (!CFLib.webSearch(this, this.getPackageName(), postCallManager.getDeviceId(), postCallManager.getSearchUrl(), paramQuery))
//		if (!CFLib.webSearch2(this, postCallManager.getSearchUrl()))
		{
			Toast.makeText(this, getResources().getString(R.string.msgNoBrowser), Toast.LENGTH_SHORT).show();
		}
	}

	
	@Override
	public void onBannerDownloaded(final String bannerHtml)
	{
		CFFunctions.logD(CFConstants.TAG, "onBannerDownloaded -> bannerHtml: " + bannerHtml);
				
		// Banner received, show it
		runOnUiThread(new Runnable()
		{

			public void run()
			{
				showBanner(bannerHtml);
			}
		});
	}
	
	
	private void showAds()
	{
		// CFLib.loadAdBannerStartApp(this, null, null, null, null, this);  // Replaced on the fly request with the line below, which tries to load the banner from cache
		this.onBannerDownloaded(postCallManager.getPreference(CFConstants.PREF_KEY_STARTAPP_BANNER, ""));
	}


	@SuppressWarnings("unused")
	private void hideAds()
	{
		llAds.setVisibility(View.GONE);
	}

	
	// Launch the developer's app
	private void launchMainApp()
	{
		this.localyticsSession.tagEvent("Call Terminate - Powered by");
		
		cancelAutoHideScreen();
		try
		{
			PackageManager pm = getPackageManager();
			Intent intent = pm.getLaunchIntentForPackage(this.getPackageName());
			startActivity(intent);
		}
		catch (Exception e)
		{
		}
	}

	private void autoHideScreen()
	{
		handlerAutoHideScreen = new Handler();
		runnableAutoHideScreen = new Runnable()
		{
	
			@Override
			public void run()
			{
				try
				{
					cancelAutoHideScreen();
					
					finish();
					
					sendAppToBackground();
				}
				catch (Exception e)
				{
				}
			}
		};
		handlerAutoHideScreen.postDelayed(runnableAutoHideScreen, CFConstants.MSECS_BEFORE_CALL_TERMINATE_AUTOHIDE);
	}

	/**
	 * Sends the parent application to background
	 */
	protected void sendAppToBackground() {

		Intent i = new Intent();
		i.setAction(Intent.ACTION_MAIN);
		i.addCategory(Intent.CATEGORY_HOME);
		this.startActivity(i);
	}


	private void cancelAutoHideScreen()
	{
		if (handlerAutoHideScreen != null)
		{
			handlerAutoHideScreen.removeCallbacksAndMessages(null);
		}
	}
	
	private void reEnableActionButtons()
	{
		Handler handlerReEnableActionButtons = new Handler();
		Runnable runnableReEnableActionButtons = new Runnable()
		{

			@Override
			public void run()
			{
				try
				{
					if (btnText != null)
					{
						btnText.setEnabled(true);
					}
					if (btnEmail != null)
					{
						btnEmail.setEnabled(true);
					}
					if (btnMeeting != null)
					{
						btnMeeting.setEnabled(true);
					}
					if (btnCall != null)
					{
						btnCall.setEnabled(true);
					}
				}
				catch (Exception e)
				{
				}
			}
		};
		handlerReEnableActionButtons.postDelayed(runnableReEnableActionButtons, 1000);
	}


	// Start an auto-complete suggestions request
	private void requestAutoComplete(String searchQuery)
	{
		// Encode the query
		List<NameValuePair> pairs = new ArrayList<NameValuePair>();
		pairs.add(new BasicNameValuePair("q", searchQuery.toString()));
		String paramString = URLEncodedUtils.format(pairs, "utf-8");

		final String url = CFConstants.URL_AUTO_COMPLETE + paramString;
		
		Runnable runnableAutoComplete = new Runnable()
		{
			public void run()
			{
				try
				{
					lastAutoCompleteRequestTime = new Date().getTime();					
					
					CFFunctions.logD(CFConstants.TAG, "ActivityCallTerminate.requestAutoComplete -> Requesting autocomplete: " + url);
					AsyncTaskAutoComplete taskAutoComplete = new AsyncTaskAutoComplete(txtWebSearch, url);
					taskAutoComplete.execute();
				}
				catch (Exception e)
				{
				}
			}
		};
	
		if ((hndAutoComplete != null) && ((new Date().getTime()) - lastAutoCompleteRequestTime) < CFConstants.MSECS_BETWEEN_AUTOCOMPLETE_REQUESTS)
		{
			hndAutoComplete.removeCallbacksAndMessages(null);
		}
			
		if (hndAutoComplete == null)
		{
			hndAutoComplete = new Handler();
		}
		
		try
		{
			if (taskAutoComplete != null)
			{
				taskAutoComplete.cancel(true);
			}
		}
		catch (Exception e)
		{
		}
		hndAutoComplete.postDelayed(runnableAutoComplete, CFConstants.MSECS_BETWEEN_AUTOCOMPLETE_REQUESTS);
	}


	private void showBanner(final String bannerHtml) {
		llAds.removeAllViews();

		// If no banner received, show AdMob ads
		if ((bannerHtml == null) || (bannerHtml.compareTo("") == 0))
		{
			System.out.println();
//		    		// Create the adView
//		    	    final AdView adView = CFLib.loadAdBannerAdMobStartApp(ActivityCallTerminate.this);
//		    	    adView.setAdListener(adMobListener);
//		    	    
//		    	    // Add the adView to the container
//		    	    llAds.addView(adView);
//		    	    // Initiate a generic request to load it with an ad
//		    	    llAds.setVisibility(View.VISIBLE);
//		    	    adView.loadAd(new AdRequest());
//					return;
		}

		try
		{ 
			// Detect if redirect is to be used
			try
			{
				String htmlToLower = bannerHtml.toLowerCase();
				if (htmlToLower.contains("smartredirect"))
				{
					String txt = htmlToLower.substring(htmlToLower.indexOf("smartredirect") + 14, htmlToLower.length());
					txt = txt.substring(0, (htmlToLower.indexOf(" ") - 1));
					
					CFFunctions.logD(CFConstants.TAG, "Banner header: " + txt);
					ArrayList<String> list = new ArrayList<String>();
					Collections.addAll(list, txt.split("@"));
					
					isRedirect = Boolean.parseBoolean(list.get(0));
				}
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
			
			// Show the banner
			WebView wv = new WebView(ActivityCallTerminate.this);

			LayoutParams params = new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
			wv.setLayoutParams(params);
			wv.getSettings().setJavaScriptEnabled(true);
			wv.getSettings().setPluginsEnabled(true);

			wv.setWebViewClient(new WebViewClient()
			{

				public boolean shouldOverrideUrlLoading(WebView view, String url)
				{
					
					cancelAutoHideScreen();
					localyticsSession.tagEvent("Call Terminate - Ad banner");
					CFFunctions.logD(CFConstants.TAG, "ActivityCallTerminate -> StartApp banner click");

					Intent intent = new Intent(ActivityCallTerminate.this, ActivityAdBannerURL.class);
					intent.putExtra(CFConstants.INTENT_KEY_BANNER_URL, url);
					intent.putExtra(CFConstants.INTENT_KEY_BANNER_REDIRECT, isRedirect);							
					intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
					 
					startActivity(intent);
					              
//							if (view != null)
//							{
//								view.destroy();
//							}
//							              
//							finish();
					return true;
				}


				public void onPageFinished(WebView view, String url)
				{
					System.out.println();
				}


				public void onReceivedError(WebView view, int errorCode, String description, String failingUrl)
				{
					Toast.makeText(ActivityCallTerminate.this, description, Toast.LENGTH_SHORT).show();							
				}
			});

//					final WebView wvClick = wv;
//					wv.setOnTouchListener(new OnTouchListener()
//					{
//						public boolean onTouch(View v, MotionEvent event)
//						{
//							if (event.getAction() == MotionEvent.ACTION_DOWN)
//							{
//								CFFunctions.logD(CFConstants.TAG, "ActivityCallTerminate.onBannerDownloaded -> StartApp banner touched");
//								clAdBanner.onClick(wvClick);
//								return false;
//							}
//							
//							return false;
//						}
//					});
			
			wv.loadDataWithBaseURL("notreal/", bannerHtml, "text/html", "utf-8", null);
			wv.setBackgroundColor(getResources().getColor(R.color.transparent));
			
			llAds.setVisibility(View.VISIBLE);
			llAds.addView(wv);
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
	}


	private TextWatcher textWatcherWebSearch = new TextWatcher()
	{

		public void afterTextChanged(Editable s)
		{
		}


		public void beforeTextChanged(CharSequence s, int start, int count, int after)
		{
		}


		public void onTextChanged(CharSequence s, int start, int before, int count)
		{
			if ((s == null) || (s.length() == 0))
			{
				try
				{
					if (taskAutoComplete != null)
					{
						taskAutoComplete.cancel(true);
					}
				}
				catch (Exception e)
				{
				}
				
				ArrayAdapter<String> adapter = null;
				txtWebSearch.setAdapter(adapter);
				
				return;
			}
			else
			{
				cancelAutoHideScreen();
			}

			localyticsSession.tagEvent("Call Terminate - Search text changed");
			requestAutoComplete(s.toString());
		}

	};

	
	private class ReceiverCallEvents extends BroadcastReceiver
	{

		@Override
		public void onReceive(Context context, Intent intent)
		{
			int lAction = 0;

			// For call finishing
			if (intent.hasExtra(CFConstants.INTENT_KEY_CALL_FINISHED))
			{
				lAction = intent.getIntExtra(CFConstants.INTENT_KEY_CALL_FINISHED, 0);
				if (lAction == CFConstants.INTENT_ACTION_CALL_FINISHED)
				{
					try
					{
						cancelAutoHideScreen();
						ActivityCallTerminate.this.finish();
					}
					catch (Exception e)
					{
					}
				}
			}
		}
	}
}
