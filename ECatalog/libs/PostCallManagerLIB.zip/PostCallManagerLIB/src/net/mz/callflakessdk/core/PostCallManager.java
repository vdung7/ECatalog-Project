package net.mz.callflakessdk.core;

import java.util.ArrayList;

import net.mz.callflakessdk.R;
import android.app.AlertDialog;
import android.app.KeyguardManager;
import android.app.KeyguardManager.KeyguardLock;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Handler;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.provider.Settings;

import com.postcallmanager.android.PostCallWrapper;
import com.postcallmanager.android.base.StartAppSettings;
import com.postcallmanager.android.model.AdPreferences;
import com.startapp.android.eula.EULAAcceptanceListener;
import com.startapp.android.eula.EULAManager;
import com.startapp.android.eula.model.SDKVersion;


/**
 * This class manages the PostCallManager SDK configuration and provides helper functions to the other components of the SDK.
*/
public class PostCallManager
{
	private Context context = null;

	private String appName = "";
	
	private String adBannerUrl = "";
	private String freeAppsUrl = "";
	private String searchUrl = "";
	private String disableUrl = "";
	
	private String appShareIntent = "";
	private int appShareIntentFlags = 0;
	private boolean enablePostCallScreen = true;
	private boolean userAcceptShown = false;
	private String deviceId = "";
	
	private PhoneContact tempPhoneContact = null;

	private Handler handlerRevertScreen = null;
	private Runnable revertScreen = null;
	
	private static KeyguardLock keyLock = null;
	private static WakeLock wakeLock = null;


    /**
     * Constructs a new PostCallManager object.
     *
     * @param context The context used to access resources on behalf of the app. Cannot be null.
     * @throws IllegalArgumentException if {@code context} is null
     */
	public PostCallManager(Context context)
	{
		if (context == null)
		{
			throw new IllegalArgumentException("Context cannot be null");
		}
		this.context = context;
		loadSettings();
	}

	public void init() {
		final AdPreferences adPreferences = new AdPreferences();
		init(adPreferences);
	}

	public void init(final AdPreferences adPreferences) {

		EULAManager em = new EULAManager(context, SDKVersion.POSTCALL_SDK);
		if (em.acceptedEula(new EULAAcceptanceListener() {

			@Override
			public void eulaAccepted() {
				PostCallWrapper startappWrapper = new PostCallWrapper(context, adPreferences);
				StartAppSettings settings = startappWrapper.setSettings();
				initPostCallManager(true, settings.getBannerUrl(), settings.getOfferwallUrl(), settings.getSearchUrl(), settings.getDisableUrl());

			}

			@Override
			public void eulaDeclined() {
				initPostCallManager(false, "", "", "", "");

			}
		}))
			;

	}

    /**
     * Initializes the PostCallManager object with all necessary data.
     * </br>
     * The first time your app is run, it will display the PostCallManager SDK User Accept dialog.
     * </br>
     * PostCallManager SDK will use the application label defined in your AndroidManifest.xml file.
     */
	public boolean initPostCallManager(String adBannerUrl, String freeAppsUrl, String searchUrl, String disableUrl)
	{
		try
		{
			loadSettings();
			
			String appName = "";

	        // Get app name
	        PackageManager pm = context.getPackageManager();
	        String packageName = context.getPackageName();
	        if (pm != null)
	        {
	        	ApplicationInfo ai = pm.getApplicationInfo(packageName, 0);
	        	appName = pm.getApplicationLabel(ai).toString();
	        }
	        
	        
	        return initPostCallManager(appName, null, 0, enablePostCallScreen,adBannerUrl, freeAppsUrl, searchUrl, disableUrl);
		}
		catch (Exception e)
		{
			return false;
		}
	}


    /**
     * Initializes the PostCallManager object with all necessary data.
     * </br>
     * The first time your app is run, it will display the PostCallManager SDK User Accept dialog
     * </br>
     * @param appName Your application's name, which will appear on the Call Terminate Screen.
     */
	public boolean initPostCallManager(String appName, String adBannerUrl, String freeAppsUrl, String searchUrl, String disableUrl)
	{
		loadSettings();
        return initPostCallManager(appName, null, 0, enablePostCallScreen, adBannerUrl, freeAppsUrl, searchUrl, disableUrl);
	}

	
    /**
     * Initializes the PostCallManager object with all necessary data, except your application's name, share intent filter name, and intent flags.
     * </br>
     * The first time your app is run, it will display the PostCallManager SDK User Accept dialog.
     * </br>
     * PostCallManager SDK will use the application label defined in your AndroidManifest.xml file
     * @param enablePostCallScreen Flag which allows you to control whether the Call Terminate screen is displayed or not.
     * </br>
     * 							   true - Call Terminate screen will be displayed
     * </br>
     * 							   false - Call Terminate screen will not be displayed
     */
	public boolean initPostCallManager(boolean enablePostCallScreen, String adBannerUrl, String freeAppsUrl, String searchUrl, String disableUrl)
	{
		try
		{
			String appName = "";

	        // Get app name
	        PackageManager pm = context.getPackageManager();
	        String packageName = context.getPackageName();
	        if (pm != null)
	        {
	        	ApplicationInfo ai = pm.getApplicationInfo(packageName, 0);
	        	appName = pm.getApplicationLabel(ai).toString();
	        }
	        
	        
	        return initPostCallManager(appName, null, 0, enablePostCallScreen, adBannerUrl, freeAppsUrl, searchUrl, disableUrl);
		}
		catch (Exception e)
		{
			return false;
		}
	}


    /**
     * Initializes the PostCallManager object with all necessary data, except your share intent filter name, and intent flags.
     * </br>
     * The first time your app is run, it will display the PostCallManager SDK User Accept dialog.
     * </br>
     * @param appName Your application's name, which will appear on the Call Terminate Screen.
     * @param enablePostCallScreen Flag which allows you to control whether the Call Terminate screen is displayed or not.
     * </br>
     * 							   true - Call Terminate screen will be displayed
     * </br>
     * 							   false - Call Terminate screen will not be displayed
     */
	public boolean initPostCallManager(String appName, boolean enablePostCallScreen,
								  String adBannerUrl, String freeAppsUrl, String searchUrl, String disableUrl)
	{
        return initPostCallManager(appName, null, 0, enablePostCallScreen, adBannerUrl, freeAppsUrl, searchUrl, disableUrl);
	}

	
    /**
     * Initializes the PostCallManager object with all necessary data, except your application's name.
     * </br>
     * The first time your app is run, it will display the PostCallManager SDK User Accept dialog.
     * </br>
     * PostCallManager SDK will use the application label defined in your AndroidManifest.xml file
     * <p>
     * @param appShareIntent Activity intent-filter declared in your app's AndroidManifest.xml file.
     * </br>
     * 						 Allows you to implement custom behavior for the Share button click event (for example, Share only on Facebook).
     * </br>
     * 						 This intent-filter will be used to launch your activity when the Share button on the Call Terminate screen is clicked.
     * </br>
     * 						 The default share dialog will not be displayed.
     * @param appShareIntentFlags Used only when appShareIntent is specified.
     * </br>
     * 							  Use any of the standard Intent flags to launch your activity.
     * @param enablePostCallScreen Flag which allows you to control whether the Call Terminate screen is displayed or not.
     * </br>
     * 							   true - Call Terminate screen will be displayed
     * </br>
     * 							   false - Call Terminate screen will not be displayed
     */
	@SuppressWarnings("unused")
	private boolean initPostCallManager(String appShareIntent, int appShareIntentFlags, boolean enablePostCallScreen,
								   String adBannerUrl, String freeAppsUrl, String searchUrl, String disableUrl)
	{
		try
		{
			String appName = "";

	        // Get app name
	        PackageManager pm = context.getPackageManager();
	        String packageName = context.getPackageName();
	        if (pm != null)
	        {
	        	ApplicationInfo ai = pm.getApplicationInfo(packageName, 0);
	        	appName = pm.getApplicationLabel(ai).toString();
	        }
	        
	        
	        return initPostCallManager(appName, appShareIntent, appShareIntentFlags, enablePostCallScreen, adBannerUrl, freeAppsUrl, searchUrl, disableUrl);
		}
		catch (Exception e)
		{
			return false;
		}
	}


    /**
     * Initializes the PostCallManager object with all necessary data.
     * </br>
     * The first time your app is run, it will display the PostCallManager SDK User Accept dialog.
     * @param appName Your application's name, which will appear on the Call Terminate Screen.
     * <p>
     * @param appShareIntent Activity intent-filter declared in your app's AndroidManifest.xml file.
     * </br>
     * 						 Allows you to implement custom behavior for the Share button click event (for example, Share only on Facebook).
     * </br>
     * 						 This intent-filter will be used to launch your activity when the Share button on the Call Terminate screen is clicked.
     * </br>
     * 						 The default share dialog will not be displayed.
     * @param appShareIntentFlags Used only when appShareIntent is specified.
     * </br>
     * 							  Use any of the standard Intent flags to launch your activity.
     * @param enablePostCallScreen Flag which allows you to control whether the Call Terminate screen is displayed or not.
     * </br>
     * 							   true - Call Terminate screen will be displayed
     * </br>
     * 							   false - Call Terminate screen will not be displayed
     */
	private boolean initPostCallManager(String appName, String appShareIntent, int appShareIntentFlags, boolean enablePostCallScreen,
								   String adBannerUrl, String freeAppsUrl, String searchUrl, String disableUrl)
	{
        // Sanity checks before init
        if (appName == null)
        {
        	appName = "";
        }
        if (appShareIntent == null)
        {
        	appShareIntent = "";
        }

        // Init
		this.appName = appName;
		this.appShareIntent = appShareIntent;
		this.appShareIntentFlags = appShareIntentFlags;
		this.enablePostCallScreen = enablePostCallScreen;
		this.adBannerUrl = adBannerUrl;
		this.freeAppsUrl = freeAppsUrl;
		this.searchUrl = searchUrl;
		this.disableUrl = disableUrl;
		
		return saveSettings();
		
		// showUserAccept();
	}

	
	@SuppressWarnings("unused")
	private void showUserAccept()
	{
		loadSettings();
		
		if (!userAcceptShown)
		{
			userAcceptShown = true;
			saveSettings();

			Intent intent = new Intent(getContext(), ActivityWelcome.class);
			getContext().startActivity(intent);
		}
	}

	
	private boolean saveSettings()
	{
		boolean result = false;
		
		try
		{
			setPreference(CFConstants.PREF_KEY_APP_NAME, appName);
			setPreference(CFConstants.PREF_KEY_APP_SHARE_INTENT, appShareIntent);
			setPreference(CFConstants.PREF_KEY_APP_SHARE_INTENT_FLAGS, appShareIntentFlags);
			setPreference(CFConstants.PREF_KEY_ENABLE_POST_CALL_SCREEN, enablePostCallScreen);
			setPreference(CFConstants.PREF_KEY_USER_ACCEPT_SHOWN, userAcceptShown);
			setPreference(CFConstants.PREF_KEY_DEVICE_ID, deviceId);
			
			setPreference(CFConstants.PREF_KEY_AD_BANNER_URL, adBannerUrl);
			setPreference(CFConstants.PREF_KEY_FREE_APPS_URL, freeAppsUrl);
			setPreference(CFConstants.PREF_KEY_SEARCH_URL, searchUrl);
			setPreference(CFConstants.PREF_KEY_DISABLE_URL, disableUrl);
			
			result = true;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		return result;
	}
	
	
	private void loadSettings()
	{
		try
		{
			appName = getPreference(CFConstants.PREF_KEY_APP_NAME, "");
			appShareIntent = getPreference(CFConstants.PREF_KEY_APP_SHARE_INTENT, "");
			appShareIntentFlags = getPreference(CFConstants.PREF_KEY_APP_SHARE_INTENT_FLAGS, 0);
			enablePostCallScreen = getPreference(CFConstants.PREF_KEY_ENABLE_POST_CALL_SCREEN, true);
			userAcceptShown = getPreference(CFConstants.PREF_KEY_USER_ACCEPT_SHOWN, false);
			deviceId = getPreference(CFConstants.PREF_KEY_DEVICE_ID, CFFunctions.getDeviceUUID(getContext()));
			
			adBannerUrl = getPreference(CFConstants.PREF_KEY_AD_BANNER_URL, "");
			freeAppsUrl = getPreference(CFConstants.PREF_KEY_FREE_APPS_URL, "");
			searchUrl = getPreference(CFConstants.PREF_KEY_SEARCH_URL, "");
			disableUrl = getPreference(CFConstants.PREF_KEY_DISABLE_URL, "");
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	

	protected String getDeviceId()
	{
		// Load from saved settings first
		if ((deviceId == null) || (deviceId.length() <= 0))
		{
			loadSettings();
		}
		
		
		// If not found in settings, get it
		if ((deviceId == null) || (deviceId.length() <= 0))
		{
			loadSettings();
			deviceId = CFFunctions.getDeviceUUID(getContext());
			saveSettings();
		}
		
		return deviceId;
	}

	
	protected void chooseEmail(Context context, long idContact, final EmailSelectListener emailSelectListener)
	{
		// Fill our list with the contact's emails
		PhoneContact phoneContact = null;

		// For the case when we don't have the contacts list available...
		if (phoneContact == null)
		{
			phoneContact = tempPhoneContact;
		}
		
		if (phoneContact == null)
		{
			phoneContact = PhoneContactsList.getContactById(context, idContact);
		}
			
		if (phoneContact == null)
		{
			return;
		}

		// ArrayList<String> emailsArray = phoneContact.getEmails();
		ArrayList<String> emailsArray = PhoneContactsList.loadContactEmails(context, phoneContact.getId());
		if ((phoneContact == null) || (emailsArray == null) || (emailsArray.size() <= 0))
		{
			emailSelectListener.onEmailSelected(null);
			return;
		}
		
		// If there's only one email for this contact, return it
		if (emailsArray.size() == 1)
		{
			emailSelectListener.onEmailSelected(emailsArray.get(0));
			return;
		}
		

		// Prepare and show the dialog
		final CharSequence[] emails = emailsArray.toArray(new CharSequence[emailsArray.size()]);
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setTitle(context.getResources().getString(R.string.strChooseEmail));
		
		builder.setItems(emails, new DialogInterface.OnClickListener()
		{
			public void onClick(DialogInterface dialog, int item)
			{
				emailSelectListener.onEmailSelected(emails[item].toString());
				dialog.dismiss();
			}
		});
		

		try
		{
			AlertDialog alert = builder.create();
			alert.show();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}


	protected void handlePhoneCall(Context context, int action, long idContact, String phoneNumber) throws Exception
	{
		try
		{
			CFFunctions.logD(CFConstants.TAG, "PostCallManager.handlePhoneCall -> context: " + context);
			CFFunctions.logD(CFConstants.TAG, "PostCallManager.handlePhoneCall -> action: " + action);
			CFFunctions.logD(CFConstants.TAG, "PostCallManager.handlePhoneCall -> idContact: " + idContact);
			CFFunctions.logD(CFConstants.TAG, "PostCallManager.handlePhoneCall -> phoneNumber: " + phoneNumber);
		}
		catch (Exception e)
		{
		}
		
		switch (action)
			{
			case CFConstants.CALL_ACTION_CALL:
				String url = "tel:" + phoneNumber;
				// Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse(url));
				Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse(url));
				PackageManager pm = context.getPackageManager();
				if (pm.resolveActivity(intent, 0) != null)
				{
					context.startActivity(intent);
				}
				break;
			default:
				break;
			}
	}

	
	protected long getScreenTimeout()
	{
		int timeOut = 15000;
		
		if (getContext() == null)
		{
			return timeOut;
		}
		timeOut = Settings.System.getInt(getContext().getContentResolver(), Settings.System.SCREEN_OFF_TIMEOUT, 15000);
		
		CFFunctions.logD(CFConstants.TAG, "CFCore.getScreenTimeout() -> timeOut: " + timeOut);
		return timeOut;
	}
	
	
	protected void turnOnScreen()
	{
		if (getContext() == null)
		{
			return;
		}

		try
		{
			// Release wake lock, if existing
			reEnableScreenPowerOff();
			
			// Turn screen on
			PowerManager pwrMgr = (PowerManager) getContext().getSystemService(Context.POWER_SERVICE);
			wakeLock = pwrMgr.newWakeLock(PowerManager.ACQUIRE_CAUSES_WAKEUP | PowerManager.FULL_WAKE_LOCK, CFConstants.WAKELOCK_NAME_UNLOCK_SCREEN);
			wakeLock.acquire();
		}
		catch (Exception e)
		{
			wakeLock = null;
			e.printStackTrace();
		}
	}
	

	protected void reEnableScreenPowerOff()
	{
		try
		{
			// Release wake lock
			if (wakeLock != null)
			{
				wakeLock.release();
				wakeLock = null;
			}
		}
		catch (Exception e)
		{
			wakeLock = null;
			e.printStackTrace();
		}
	}

	
	protected static boolean isScreenLocked(Context context)
	{
		if (context == null)
		{
			return false;
		}
		
		KeyguardManager kgMgr = (KeyguardManager) context.getSystemService(Context.KEYGUARD_SERVICE);
		return kgMgr.inKeyguardRestrictedInputMode();
	}

	
	protected void unlockScreen()
	{
		if (getContext() == null)
		{
			return;
		}
		
		try
		{
			// Re-enable screen lock, if existing 
			reEnableScreenLock();
			
			// Disable keyguard
			KeyguardManager keyMgr = (KeyguardManager) getContext().getSystemService(Context.KEYGUARD_SERVICE);
			keyLock = keyMgr.newKeyguardLock(CFConstants.WAKELOCK_NAME_UNLOCK_SCREEN);
			keyLock.disableKeyguard();
		}
		catch (Exception e)
		{
			keyLock = null;
			e.printStackTrace();
		}
	}


	protected void reEnableScreenLock()
	{
		try
		{
			// Re-enable keyguard
			if (keyLock != null)
			{
				keyLock.reenableKeyguard();
				keyLock = null;
			}
		}
		catch (Exception e)
		{
			keyLock = null;
			e.printStackTrace();
		}
	}
	

	protected void revertScreenStatus(final boolean onlyScreenPower)
	{
		handlerRevertScreen = new Handler();
		revertScreen = new Runnable()
		{
			@Override
			public void run()
			{
				if (!onlyScreenPower)
				{
					reEnableScreenLock();
				}
				reEnableScreenPowerOff();						
			}
		};
		handlerRevertScreen.postDelayed(revertScreen, getScreenTimeout());
	}
	

	protected void cancelRevertScreenStatus()
	{
		if (handlerRevertScreen != null)
		{
			if (revertScreen != null)
			{
				handlerRevertScreen.removeCallbacks(revertScreen);
			}
			
			handlerRevertScreen = null;
		}
	}


	protected void clearTempState()
	{
		if (tempPhoneContact != null)
		{
			tempPhoneContact = null;
		}
	}
	
		
	protected PhoneContact getTempPhoneContact(String phoneNumber)
	{
		if ((phoneNumber == null) || (phoneNumber.length() <= 0))
		{
			return null;
		}
		
		tempPhoneContact = PhoneContactsList.getContactWithPhoneNumber(getContext(), phoneNumber);
		CFFunctions.logD(CFConstants.TAG, "CFCore.getTempPhoneContact -> (tempPhoneContact != null): " + (tempPhoneContact != null));
		if (tempPhoneContact != null)
		{
			CFFunctions.logD(CFConstants.TAG, "CFCore.getTempPhoneContact -> tempPhoneContact.name: " + tempPhoneContact.getName());
		}
		return tempPhoneContact;
	}

	
	protected void setTempPhoneContact(PhoneContact tempPhoneContact)
	{
		this.tempPhoneContact = tempPhoneContact;
	}
	
	
	// Preferences methods
	// For String data
	protected void setPreference(String key, String data)
	{
		getSettings();
		Editor preferenceEditor = getSettings().edit();
		preferenceEditor.putString(key, data);
		preferenceEditor.commit();
	}


	protected String getPreference(String key, String defaultValue)
	{
		getSettings();
		return getSettings().getString(key, defaultValue);
	}
	
	// Preferences methods
	// For int data
	protected void setPreference(String key, int data)
	{
		getSettings();
		Editor preferenceEditor = getSettings().edit();
		preferenceEditor.putInt(key, data);
		preferenceEditor.commit();
	}

	protected int getPreference(String key, int defaultValue)
	{
		getSettings();
		return getSettings().getInt(key, defaultValue);
	}
	
	// For long data
	protected void setPreferenceLong(String key, long data)
	{
		getSettings();
		Editor preferenceEditor = getSettings().edit();
		preferenceEditor.putLong(key, data);
		preferenceEditor.commit();
	}

	protected long getPreferenceLong(String key, long defaultValue)
	{
		getSettings();
		return getSettings().getLong(key, defaultValue);
	}

	
	// For boolean data
	protected void setPreference(String key, boolean data)
	{
		getSettings();
		Editor preferenceEditor = getSettings().edit();
		preferenceEditor.putBoolean(key, data);
		preferenceEditor.commit();
	}


	protected boolean getPreference(String key, boolean defaultValue)
	{
		getSettings();
		return getSettings().getBoolean(key, defaultValue);
	}
	
	
	// Remove item
	protected void removePreference(String key)
	{
		Editor preferenceEditor = getSettings().edit();
		preferenceEditor.remove(key);
		preferenceEditor.commit();
	}


	protected SharedPreferences getSettings()
	{
		return getContext().getSharedPreferences(CFConstants.PREFS_NAME_POSTCALLMANAGER_SDK, Context.MODE_PRIVATE);
	}


	// Getters and setters
	public Context getContext()
	{
		return context;
	}

	
	public void setContext(Context context)
	{
		this.context = context;
	}

	public String getAppName()
	{
		return appName;
	}


	public void setAppName(String appName)
	{
		this.appName = appName;
	}


	
	public String getAdBannerUrl()
	{
		return adBannerUrl;
	}


	
	public void setAdBannerUrl(String adBannerUrl)
	{
		this.adBannerUrl = adBannerUrl;
	}


	
	public String getFreeAppsUrl()
	{
		return freeAppsUrl;
	}


	
	public void setFreeAppsUrl(String freeAppsUrl)
	{
		this.freeAppsUrl = freeAppsUrl;
	}


	
	public String getSearchUrl()
	{
		return searchUrl;
	}


	
	public void setSearchUrl(String searchUrl)
	{
		this.searchUrl = searchUrl;
	}


	
	public String getDisableUrl()
	{
		return disableUrl;
	}


	
	public void setDisableUrl(String disableUrl)
	{
		this.disableUrl = disableUrl;
	}


	public String getAppShareIntent()
	{
		return appShareIntent;
	}


	
	public void setAppShareIntent(String appShareIntent)
	{
		this.appShareIntent = appShareIntent;
	}


	
	public int getAppShareIntentFlags()
	{
		return appShareIntentFlags;
	}


	
	public void setAppShareIntentFlags(int appShareIntentFlags)
	{
		this.appShareIntentFlags = appShareIntentFlags;
	}


	public boolean isEnablePostCallScreen()
	{
		return enablePostCallScreen;
	}


	public void setEnablePostCallScreen(boolean enablePostCallScreen)
	{
		this.enablePostCallScreen = enablePostCallScreen;
		saveSettings();
	}
	
	
	public boolean isUserAcceptShown()
	{
		return userAcceptShown;
	}	
}
