package net.mz.callflakessdk.core;


import java.util.ArrayList;

import android.graphics.Bitmap;


/**
 * Holds information about a contact in the device's contacts list.
 * <p>
 * Note: this is not a public API.
 */
public class PhoneContact
{

	private long id = 0; // Contact ID
	private String name = null; // Contact name
	private Bitmap photoThumbnail = null; // Contact's thumbnail photo
	private Bitmap photoLarge = null; // Contact's large photo
	private ArrayList<String> phoneNumbers = new ArrayList<String>(); // List of phone numbers
	private ArrayList<String> emails = new ArrayList<String>(); // List of phone numbers


	/**
	 * Returns contact ID
	 * 
	 * @return contact ID
	 */
	public long getId()
	{
		return id;
	}


	/**
	 * Sets contact ID
	 * 
	 * @param id contact ID
	 */
	public void setId(long id)
	{
		this.id = id;
	}


	/**
	 * Returns contact name
	 * 
	 * @return contact name
	 */
	public String getName()
	{
		return name;
	}


	/**
	 * Sets contact name
	 * 
	 * @param name contact name
	 */
	public void setName(String name)
	{
		this.name = name;
	}


	/**
	 * Returns contact photo thumbnail
	 * 
	 * @return contact photo thumbnail
	 */
	public Bitmap getPhotoThumbnail()
	{
		return photoThumbnail;
	}


	/**
	 * Sets contact photo thumbnail
	 * 
	 * @param photoThumbnail contact photo thumbnail
	 */
	public void setPhotoThumbnail(Bitmap photoThumbnail)
	{
		this.photoThumbnail = photoThumbnail;
	}


	/**
	 * Returns contact large photo
	 * 
	 * @return contact large photo
	 */
	public Bitmap getPhotoLarge()
	{
		return photoLarge;
	}


	/**
	 * Sets contact large photo
	 * 
	 * @param photoLarge contact large photo
	 */
	public void setPhotoLarge(Bitmap photoLarge)
	{
		this.photoLarge = photoLarge;
	}


	/**
	 * Returns contact phone numbers
	 * 
	 * @return ArrayList of String containing contact phone numbers
	 */
	public ArrayList<String> getPhoneNumbers()
	{
		return phoneNumbers;
	}


	/**
	 * Sets contact phone numbers
	 * 
	 * @param phoneNumbers ArrayList of String containing contact phone numbers
	 */
	public void setPhoneNumbers(ArrayList<String> phoneNumbers)
	{
		this.phoneNumbers = phoneNumbers;
	}


	/**
	 * Returns contact email addresses
	 * 
	 * @return ArrayList of String containing contact email addresses
	 */
	public ArrayList<String> getEmails()
	{
		return emails;
	}


	/**
	 * Sets contact email addresses
	 * 
	 * @param emails ArrayList of String containing contact email addresses
	 */
	public void setEmails(ArrayList<String> emails)
	{
		this.emails = emails;
	}
}
