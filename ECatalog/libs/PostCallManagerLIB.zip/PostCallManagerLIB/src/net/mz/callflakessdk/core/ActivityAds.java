package net.mz.callflakessdk.core;

import java.util.ArrayList;

import net.mz.callflakessdk.R;
import net.mz.callflakessdk.libcfint.BannerDownloadListener;
import net.mz.callflakessdk.libcfint.CFLib;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebView.HitTestResult;
import android.webkit.WebViewClient;

import com.localytics.android.LocalyticsSession;


/**
 * Activity used to display Free Apps.
 * </br>
 * Launched when the user clicks the Free Apps button on the PostCallManager SDK Call Terminate screen.
 * <p>
 * Note: this is not a public API.
 */
public class ActivityAds extends Activity implements BannerDownloadListener
{
	private LocalyticsSession localyticsSession;
	private WebView wvAppWall = null;
	private ProgressDialog dialogLoadingProgress = null;
	private ArrayList<Boolean> redirectIndexes = new ArrayList<Boolean>();
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_ads);
		
		// Find views
		wvAppWall = (WebView) findViewById(R.id.wvAppWall);
		
		// Analytics
	    this.localyticsSession = CFLib.getLocalyticsSessionStartApp(this);	 
	    this.localyticsSession.open();
	    this.localyticsSession.upload();
	}
	
	@Override
	protected void onStart()
	{
		super.onStart();		
	}
	
	
	@Override
	protected void onStop()
	{
		super.onStop();
	}
	
	
	@Override
	protected void onResume()
	{
		super.onResume();
		
		this.localyticsSession.open();

		// Display a "Loading..." ProgressDialog 
		showLoadingDialog();


		// Create a PostCallManager instance to get device ID
		// PostCallManager postCallManager = new PostCallManager(this);
		// Launch Free Apps URL in web browser
		// CFLib.loadUrl(wvAppWall, this.getPackageName(), postCallManager.getDeviceId());
		
		PostCallManager postCallManager = new PostCallManager(this);
		CFLib.loadAdBannerStartApp2(postCallManager.getFreeAppsUrl(), this);
	}
	
	
	@Override
	public void onBannerDownloaded(final String bannerHtml)
	{
		CFFunctions.logD(CFConstants.TAG, "onBannerDownloaded -> bannerHtml: " + bannerHtml);
				
		// Banner received, show it
		runOnUiThread(new Runnable()
		{

			public void run()
			{
				try
				{ 
//					// Build the list of Smart Redirect booleans for each of the apps displayed in the list
//					try
//					{
//						String htmlToLower = bannerHtml.toLowerCase();
//						if (htmlToLower.contains("smartredirect"))
//						{
//							// Extract substrings untile we have only the true/false enumeration
//							String txt = htmlToLower.substring(htmlToLower.indexOf("smartredirect") + 14, htmlToLower.length());
//							txt = txt.substring(0, (htmlToLower.indexOf(" ") - 1));
//							txt = txt.substring(0, txt.indexOf("@"));
//							
//							// Add the boolean values to a collection which will be used later, if an app from the list is clicked
//							CFFunctions.logD(CFConstants.TAG, "Banner header: " + txt);
//							ArrayList<String> list = new ArrayList<String>();
//							Collections.addAll(list, txt.split(","));
//							
//							for (int i = 0; i < list.size(); i++)
//							{
//								redirectIndexes.add(Boolean.parseBoolean(list.get(i)));
//							}
//						}
//					}
//					catch (Exception e)
//					{
//						e.printStackTrace();
//					}
					
					// Show the Free Apps list in a WebView
					// Create a WebView and configure it
					WebSettings settings = wvAppWall.getSettings();
					settings.setJavaScriptEnabled(true);
					settings.setPluginsEnabled(true);
					settings.setBuiltInZoomControls(true);
					wvAppWall.setScrollBarStyle(WebView.SCROLLBARS_OUTSIDE_OVERLAY);
					
					// close the appwall when the user hits the 'X' from top-left corner in the web view 
					wvAppWall.setOnTouchListener(new OnTouchListener() {
						
						@Override
						public boolean onTouch(View v, MotionEvent event) {
							WebView.HitTestResult hr = ((WebView) v).getHitTestResult();

							if (hr != null) {
								switch (hr.getType()) {
								case HitTestResult.IMAGE_TYPE:
									if (hr.getExtra().contains(CFConstants.APPWALL_CLOSE_BUTTON_NAME)) {
										ActivityAds.this.onBackPressed();
										return true;
									}
									break;
								}
							}
							return false;
						}
					});
					
					wvAppWall.setWebViewClient(new WebViewClient()
					{

						public boolean shouldOverrideUrlLoading(WebView view, String url)
						{
//							// A Free App has been clicked. Get the URL and the Smart Redirect flag from the list we built earlier.
//							String urlToLower = url.toLowerCase();
//							boolean isRedirect = false;
//							
//							// isRedirect = true when the flag list is empty
//							if(redirectIndexes.size() == 0)
//								isRedirect = true;
//														
//							if (urlToLower.contains("index="))
//							{
//								try
//								{
//									String index = urlToLower.substring(urlToLower.indexOf("index="), urlToLower.length());
//									index = index.substring((index.indexOf("=") + 1), index.length());
//									CFFunctions.logD(CFConstants.TAG, "index: " + index);
//									
//									
//									if(redirectIndexes.size() > Integer.parseInt(index))
//										isRedirect = redirectIndexes.get(Integer.parseInt(index));
//									else
//										isRedirect = true;
//									CFFunctions.logD(CFConstants.TAG, "isRedirect: " + isRedirect);
//								}
//								catch (Exception e)
//								{
//									e.printStackTrace();
//								}
//							}
//							
//							
//							// Use the clicked URL and the Smart Redirect flag for the corresponding app to launch ActivityAdBannerURL, which will further handle everything
//							Intent intent = new Intent(ActivityAds.this, ActivityAdBannerURL.class);
//							intent.putExtra(CFConstants.INTENT_KEY_BANNER_URL, url);
//							intent.putExtra(CFConstants.INTENT_KEY_BANNER_REDIRECT, isRedirect);							
//							intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
//
//							startActivity(intent);
//
//							// Finish this activity
//							if (view != null)
//							{
//								view.destroy();
//							}
//							              
//							finish();
//
							
							return false;
						}


						public void onPageFinished(WebView view, String url)
						{
							try
							{
								hideLoadingDialog();
							}
							catch (Exception e)
							{
							}
						}


						public void onReceivedError(WebView view, int errorCode, String description, String failingUrl)
						{
//							Toast.makeText(ActivityAds.this, description, Toast.LENGTH_SHORT).show();
							
						    if (failingUrl != null && failingUrl.startsWith("market://")) {
						    	view.destroy();
						        ActivityAds.this.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(failingUrl)));
						    }
						}
					});
					
//					wvAppWall.loadDataWithBaseURL("notreal/", bannerHtml, "text/html", "utf-8", null);
					wvAppWall.loadUrl(new PostCallManager(ActivityAds.this).getFreeAppsUrl());
				}
				catch (Exception ex)
				{
					ex.printStackTrace();
				}
			}
		});
	}

	@Override
	protected void onPause()
	{
		// Analytics
		this.localyticsSession.close();
	    this.localyticsSession.upload();

		super.onPause();
	}
	
	
    /**
     * Creates and displays a standard {@link android.app#ProgressDialog} with the message "Loading..." 
     */
	public void showLoadingDialog()
	{
		if (dialogLoadingProgress != null)
		{
			return;
		}
		
		try
		{
			dialogLoadingProgress = ProgressDialog.show(this, "", getResources().getString(R.string.strLoading), false);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}


    /**
     * Hides the ProgressDialog created using {@link #showLoadingDialog() showLoadingDialog}
     */
	public void hideLoadingDialog()
	{
		try
		{
			if (dialogLoadingProgress != null)
			{
				dialogLoadingProgress.dismiss();
				dialogLoadingProgress = null;
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
}
