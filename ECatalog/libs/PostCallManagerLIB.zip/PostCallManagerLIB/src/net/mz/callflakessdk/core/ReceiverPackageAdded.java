package net.mz.callflakessdk.core;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;


/**
 * Broadcast Receiver used for detecting the installation of another app which integrates PostCallManager SDK.
 * You must declare this Broadcast Receiver in your app's AndroidManifest.xml file.
 * <p>
 * Note: this is not a public API.
 */
public class ReceiverPackageAdded extends BroadcastReceiver
{
	@Override
	public void onReceive(Context context, Intent intent)
	{
		// Get installed package name
        Uri data = intent.getData();
        String packageName = data.getEncodedSchemeSpecificPart();
        CFFunctions.logD(CFConstants.TAG, "ReceiverPackageAdded.onReceive -> The installed package is: " + packageName);
        
        try
        {
	        // Get installed package info
	        PackageManager pm = context.getPackageManager();
	        if (pm == null)
	        {
	        	CFFunctions.logD(CFConstants.TAG, "ReceiverPackageAdded.onReceive -> Could not get PackageManager, exiting...");
	        	return;
	        }
        
	        // Get all receivers contained in installed package
        	PackageInfo pi = pm.getPackageInfo(packageName, PackageManager.GET_RECEIVERS);
        	if ((pi == null) || (pi.receivers == null) || (pi.receivers.length <= 0))
        	{
        		CFFunctions.logD(CFConstants.TAG, "ReceiverPackageAdded.onReceive -> Could not get PackageInfo or no receivers in package, exiting...");
        		return;
        	}
        
        	// Iterate all receivers contained in installed package
        	for (int i = 0; i < pi.receivers.length; i++)
        	{
        		ActivityInfo ai = pi.receivers[i];
        		if (ai == null)
        		{
        			continue;
        		}
        		
        		// If the installed package contains the PostCallManager or PostCallManager SDK PHONE_STATE receiver, disable this app's PHONE_STATE receiver
        		CFFunctions.logD(CFConstants.TAG, "ReceiverPackageAdded.onReceive -> Receiver " + i + " name: " + ai.name);
        		if ((ai.name.compareToIgnoreCase(CFConstants.PHONE_STATE_RECEIVER_NAME) == 0) || (ai.name.compareToIgnoreCase(CFConstants.PHONE_STATE_RECEIVER_NAME_EXTRA) == 0))
        		{
        			CFFunctions.logD(CFConstants.TAG, "ReceiverPackageAdded.onReceive -> Disabling receiver");
        			ComponentName compName = new ComponentName(context, ReceiverCall.class);
        			CFFunctions.logD(CFConstants.TAG, "ReceiverPackageAdded.onReceive -> Current receiver state: " + pm.getComponentEnabledSetting(compName));
        			pm.setComponentEnabledSetting(compName, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
        			CFFunctions.logD(CFConstants.TAG, "ReceiverPackageAdded.onReceive -> New receiver state: " + pm.getComponentEnabledSetting(compName));
        			break;
        		}
        	}
        }
        catch (Exception e)
        {
        }
	}
}
