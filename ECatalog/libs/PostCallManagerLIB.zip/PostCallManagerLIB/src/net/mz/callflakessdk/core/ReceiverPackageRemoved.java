package net.mz.callflakessdk.core;

import java.io.File;
import java.lang.reflect.Field;
import java.util.List;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;


/**
 * Broadcast Receiver used for detecting the uninstallation of an app.
 * You must declare this Broadcast Receiver in your app's AndroidManifest.xml file.
 * <p>
 * Note: this is not a public API.
 */
public class ReceiverPackageRemoved extends BroadcastReceiver
{
	@Override
	public void onReceive(Context context, Intent intent)
	{
        long currentPackageInstallTime = 0;
        
		try
		{
			// Get uninstalled package name
	        Uri data = intent.getData();
	        String packageName = data.getEncodedSchemeSpecificPart();
	        CFFunctions.logD(CFConstants.TAG, "ReceiverPackageRemoved.onReceive -> The uninstalled package is: " + packageName);
	        if (packageName == null)
	        {
	        	return;
	        }
	        
	        
	        // Get a list of installed apps
	        final PackageManager pm = context.getPackageManager();
	        if (pm == null)
	        {
	        	CFFunctions.logD(CFConstants.TAG, "ReceiverPackageRemoved.onReceive -> Could not get PackageManager, exiting...");
	        	return;
	        }
	        List<ApplicationInfo> packages = pm.getInstalledApplications(PackageManager.GET_META_DATA);
	        if ((packages == null) || (packages.size() <= 0))
	        {
	        	CFFunctions.logD(CFConstants.TAG, "ReceiverPackageRemoved.onReceive -> Could not get PackageManager, exiting...");
	        	return;
	        }
	        
	        
	        // Get current package date. If 0 or less, there was an error - exit because there's nothing to do
	        currentPackageInstallTime = getInstallTime(pm, context.getPackageName());
	        if (currentPackageInstallTime <= 0)
	        {
	        	return;
	        }
	        
	        
	        // Iterate all installed packages and check if they contain the PostCallManager/PostCallManager SDK Phone_STATE receiver
	        for (int i = 0; i < packages.size(); i++)
	        {
	        	ApplicationInfo packageInfo = packages.get(i);
	        	if (packageInfo == null)
	        	{
	        		return;
	        	}
	        	
		        // Get all receivers contained in installed package
	        	PackageInfo pi = pm.getPackageInfo(packageInfo.packageName, PackageManager.GET_RECEIVERS);
	        	if ((pi == null) || (pi.receivers == null) || (pi.receivers.length <= 0))
	        	{
	        		CFFunctions.logD(CFConstants.TAG, "ReceiverPackageRemoved.onReceive -> Could not get PackageInfo or no receivers in package, exiting...");
	        		continue;
	        	}
	        	
	        	// Iterate all receivers contained in installed package
	        	for (int j = 0; j < pi.receivers.length; j++)
	        	{
	        		ActivityInfo ai = pi.receivers[j];
	        		if (ai == null)
	        		{
	        			continue;
	        		}
	        		
	        		// If the package contains the PostCallManager SDK PHONE_STATE receiver, check package date
	        		// Exit if package is newer. We don't have anything to do, we'll leave our PHONE_STATE receiver disabled.
	        		CFFunctions.logD(CFConstants.TAG, "ReceiverPackageRemoved.onReceive -> Receiver " + j + " name: " + ai.name);
	        		if ((ai.name.compareToIgnoreCase(CFConstants.PHONE_STATE_RECEIVER_NAME) == 0) || (ai.name.compareToIgnoreCase(CFConstants.PHONE_STATE_RECEIVER_NAME_EXTRA) == 0))
	        		{
	        			CFFunctions.logD(CFConstants.TAG, "ReceiverPackageRemoved.onReceive -> Getting package date");
	        			long installTime = getInstallTime(pm, packageInfo.packageName);
	        			CFFunctions.logD(CFConstants.TAG, "ReceiverPackageRemoved.onReceive -> Package date: " + installTime);
	        			
	        			// Exit if package is newer than this app's package. That app will activate it's PHONE_STATE receiver.
	        			if (installTime > currentPackageInstallTime)
	        			{
	        				return;
	        			}
	        		}
	        	}
	        }
	        
	        
	        // No newer package found, activate PostCallManager SDK PHONE_STATE receiver belonging to this app
			CFFunctions.logD(CFConstants.TAG, "ReceiverPackageRemoved.onReceive -> Enabling OUR receiver");
			ComponentName compName = new ComponentName(context, ReceiverCall.class);
			CFFunctions.logD(CFConstants.TAG, "ReceiverPackageRemoved.onReceive -> Current receiver state: " + pm.getComponentEnabledSetting(compName));
			pm.setComponentEnabledSetting(compName, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
			CFFunctions.logD(CFConstants.TAG, "ReceiverPackageRemoved.onReceive -> New receiver state: " + pm.getComponentEnabledSetting(compName));
		}
		catch (Exception e)
		{
		}
	}
	
	
    /**
     * Returns one of the following, depending on platform:
     * </br>
     * - package installation time from package manager
     * </br>
     * - APK file modification time
     * </br>
     * - 0 if package not found or exception encountered
     * 
     * @param packageManager A PackageManager to use for getting required information about a package.
     * @param packageName Name of the package for which installation time will be returned
     * 
     * @return Package installation time
     */
	public long getInstallTime(PackageManager packageManager, String packageName)
	{
		return firstNonZero(installTimeFromPackageManager(packageManager, packageName), apkUpdateTime(packageManager, packageName));
	}


    /**
     * Returns APK file modification time
     * 
     * @param packageManager A PackageManager to use for getting required information about a package.
     * @param packageName Name of the package for which update time will be returned
     * 
     * @return Package update time or 0 if an exception has been encountered.
     */
	private long apkUpdateTime(PackageManager packageManager, String packageName)
	{
	  try
	  {
		  ApplicationInfo info = packageManager.getApplicationInfo(packageName, 0);
		  File apkFile = new File(info.sourceDir);
		  return apkFile.exists() ? apkFile.lastModified() : 0;
	  }
	  catch (Exception e)
	  {
		  return 0;
	  }
	}

	
    /**
     * Returns first installation time of a package.
     * 
     * @param packageManager A PackageManager to use for getting required information about a package.
     * @param packageName Name of the package for which update time will be returned
     * 
     * @return Package installation time or 0 if an exception has been encountered.
     */
	private long installTimeFromPackageManager(PackageManager packageManager, String packageName)
	{
		// API level 9 and above have the "firstInstallTime" field.
		// Check for it with reflection and return if present. 
		try
		{
			PackageInfo info = packageManager.getPackageInfo(packageName, 0);
			Field field = PackageInfo.class.getField("firstInstallTime");
			long timestamp = field.getLong(info);
			return timestamp;
		}
		catch (Exception e)
		{
			return 0;
		}
	}
	

    /**
     * Returns first non-zero long value from an array of long values.
     */
	private long firstNonZero(long... dates)
	{
		try
		{
			for (long date : dates)
			{
				if (date > 0)
				{
					return date;
				}
			}
		}
		catch (Exception e)
		{
		}
		
		return 0;
	}
}
