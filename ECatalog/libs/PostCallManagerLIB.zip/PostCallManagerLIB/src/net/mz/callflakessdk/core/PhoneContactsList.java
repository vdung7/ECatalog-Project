package net.mz.callflakessdk.core;


import java.io.InputStream;
import java.util.ArrayList;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.BaseColumns;
import android.provider.ContactsContract;


/**
 * Manages operations related to the Contacts database.
 * <p>
 * Note: this is not a public API.
 */
final class PhoneContactsList
{
    /**
     * Loads a contact's photo from the Contacts database
     * 
     * @param context The context used to access resources on behalf of the app. Cannot be null.
     * @param idContact ID of the contact for which the photo will be loaded.
     * 
     * @return Bitmap containing the contact's photo
     */
	public static Bitmap loadContactPhoto(Context context, long idContact)
	{
		// Sanity checks
		if (context == null)
		{
			return null;
		}
		
		try
		{
			// Get contact photo
			Uri uri = ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, idContact);
			InputStream input = ContactsContract.Contacts.openContactPhotoInputStream(context.getContentResolver(), uri);
			if (input == null)
			{
				return null;
			}
			
			// Decode and return it
			return BitmapFactory.decodeStream(input);
		}
		catch (Exception e)
		{
			return null;
		}
	}
	
	
    /**
     * Loads a contact's phone numbers from the Contacts database
     * 
     * @param context The context used to access resources on behalf of the app. Cannot be null.
     * @param idContact ID of the contact for which phone numbers will be loaded.
     * 
     * @return ArrayList<String> containing the contact's phone numbers
     */
	public static ArrayList<String> loadContactPhoneNumbers(Context context, long idContact)
	{
		// Sanity checks
		if (context == null)
		{
			return null;
		}

		// Obtain a cursor
		final Cursor cursorPhones = context.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null,
																	   ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = " + idContact,
																	   null, null);
		ArrayList<String> phoneNumbers = new ArrayList<String>();
		try
		{
			// Iterate phone numbers and add them to our ArrayList
			while (cursorPhones.moveToNext())
			{
				final String phoneNumber = cursorPhones.getString(cursorPhones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
				phoneNumbers.add(phoneNumber);
			}
		}
		finally
		{
			// Close phone numbers cursor
			if (cursorPhones != null)
			{
				cursorPhones.close();
			}
		}
		
		if (phoneNumbers.size() <= 0)
		{
			phoneNumbers = null;
		}
		
		return phoneNumbers;
	}


    /**
     * Loads a contact's email addresses from the Contacts database
     * 
     * @param context The context used to access resources on behalf of the app. Cannot be null.
     * @param idContact ID of the contact for which email addresses will be loaded.
     * 
     * @return ArrayList<String> containing the contact's email addresses
     */
	public static ArrayList<String> loadContactEmails(Context context, long idContact)
	{
		// Sanity checks
		if ((context == null) || (idContact <= 0))
		{
			return null;
		}

		// Obtain a cursor
		ArrayList<String> emails = new ArrayList<String>();
		Cursor cursorEmails = context.getContentResolver().query(ContactsContract.CommonDataKinds.Email.CONTENT_URI,null,
                			  ContactsContract.CommonDataKinds.Email.CONTACT_ID + " = " + idContact, null, null);
		try
		{
			// Iterate email addresses and add them to our ArrayList
	        while (cursorEmails.moveToNext()) 
	        {
	            String emailAddress = cursorEmails.getString(cursorEmails.getColumnIndex(ContactsContract.CommonDataKinds.Email.DATA));
	            
	            if ((!emailAddress.equalsIgnoreCase("")) && (emailAddress.contains("@"))) 
	            {
	                emails.add(emailAddress);
	            }
	        }
		}
		finally
		{
	        // Close emails cursor
			if (cursorEmails != null)
			{
				cursorEmails.close();
			}
		}
		
		if (emails.size() <= 0)
		{
			emails = null;
		}
		
		return emails;
	}
	
	
    /**
     * Loads basic information about a contact (ID and Name) from the Contacts database, based on the contact's ID.
     * This is done for performance reasons.
     * Use the other functions in this class to obtain additional information about the contact when needed.
     * 
     * @param context The context used to access resources on behalf of the app. Cannot be null.
     * @param idContact ID of the contact for which information will be loaded.
     * 
     * @return PhoneContact object populated with the ID and Name of the contact.
     */
	public static PhoneContact getContactById(Context context, long idContact)
	{	
		// Sanity checks
		if ((context == null) || (idContact <= 0))
		{
			return null;
		}

		try
		{
			// Obtain a cursor
			PhoneContact resultContact = null;
			Cursor cursorContact = context.getContentResolver().query(ContactsContract.Contacts.CONTENT_URI, null,
																	  ContactsContract.Contacts._ID + " = ?", new String[] { String.valueOf(idContact) }, null);
			try
			{
				// Get contact information
		        while (cursorContact.moveToNext()) 
		        {
					String name = cursorContact.getString(cursorContact.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
					if (name == null)
					{
						name = "";
					}
		
					resultContact = new PhoneContact();
					resultContact.setId(idContact);
					resultContact.setName(name);
					resultContact.setPhoneNumbers(null);
					resultContact.setEmails(null);
					resultContact.setPhotoLarge(null);  // photo memory
		        }
			}
			finally
			{
				// Close contact cursor
				if (cursorContact != null)
				{
					cursorContact.close();
				}
			}
			
			return resultContact;
			
		}
		catch (Exception e)
		{
			return null;
		}
	}


    /**
     * Returns a count of all the contacts in the Contacts database.
     * 
     * @param context The context used to access resources on behalf of the app. Cannot be null.
     * 
     * @return Contacts count
     */
	public static int getContactsCount(Context context)
	{
		if (context == null)
		{
			return 0;
		}
		
		try
		{
			int count = 0;
			final Cursor cursorContacts = context.getContentResolver().query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);
			try
			{
				count = cursorContacts.getCount();
			}
			finally
			{
				if (cursorContacts != null)
				{
					cursorContacts.close();
				}
			}
			
			return count;
		}
		catch (Exception e)
		{
			return 0;
		}
	}
	
	
	/**
	 * Returns a contact with the given phone number, if found.
     * 
     * @param context The context used to access resources on behalf of the app. Cannot be null.
     * @param phoneNumber Contact phone number
     * 
     * @return PhoneContact object populated with the ID and Name of the contact.
     * 		   This is done for performance reasons.
     * 		   Use the other functions in this class to obtain additional information about the contact when needed.
     */
	public static PhoneContact getContactWithPhoneNumber(Context context, String phoneNumber)
	{
		// Sanity checks
		if ((context == null) || (phoneNumber == null))
		{
			return null;
		}
		
		// Obtain a cursor 
		PhoneContact lContact = null;
		Uri uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(phoneNumber));
		ContentResolver contentResolver = context.getContentResolver();
		Cursor contactLookup = contentResolver.query(uri, null, null, null, null);
		
		try
		{
			// Get necessary information
			if (contactLookup != null && contactLookup.getCount() > 0)
			{
				contactLookup.moveToNext();
				final long contactId = contactLookup.getLong(contactLookup.getColumnIndex(BaseColumns._ID));

				String name = contactLookup.getString(contactLookup.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
				
				// Create contact object and add it to the list
				lContact = new PhoneContact();
				lContact.setId(contactId);
				lContact.setName(name);
				lContact.setPhoneNumbers(null);
				lContact.setEmails(null);
				lContact.setPhotoLarge(null);  // photo memory
			}
		}
		finally
		{
			// Close contacts cursor
			if (contactLookup != null)
			{
				contactLookup.close();
			}
		}

		return lContact;
	}
}
