package net.mz.callflakessdk.core;

import org.json.JSONArray;

import android.os.AsyncTask;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;


/**
 * AsyncTask which performs background requests for Google auto-complete suggestions
 * <p>
 * Note: this is not a public API.
 */
public class AsyncTaskAutoComplete extends AsyncTask<Void, Void, Void>
{
	private AutoCompleteTextView textView;
	private String url;
	private String[] arrSuggestions;
	
	
    /**
     * AsyncTaskAutoComplete constructor.
     * 
     * @param textView AutoCompleteTextView which will have the adapter updated in onPostExcute, to reflect auto-complete suggestions.
     * @param url Full URL used for getting auto-complete suggestions. It must include the search query.
     *  
     */
	public AsyncTaskAutoComplete(AutoCompleteTextView textView, String url)
	{
		this.textView = textView;
		this.url = url;
	}
	
	
	@Override
	protected void onPostExecute(Void result)
	{
		super.onPostExecute(result);

		// If not cancelled, set a new adapter to the AutoCompleteTextView
		if ((!isCancelled()) && (!textView.getText().toString().equals("")))
		{
			// We have suggestions
			if ((arrSuggestions != null) && (arrSuggestions.length > 0))
			{
				ArrayAdapter<String> adapter = new ArrayAdapter<String>(textView.getContext(), android.R.layout.select_dialog_item, arrSuggestions);
				textView.setAdapter(adapter);
				textView.showDropDown();
			}
			// No suggestions
			else
			{
				ArrayAdapter<String> adapter = null;
				textView.setAdapter(adapter);
			}
		}
	}
	
	
	@Override
	protected Void doInBackground(Void... params)
	{
		// Sanity checks
		if (textView == null)
		{
			CFFunctions.logD(CFConstants.TAG, "AsyncTaskAutoComplete.execute -> textView is NULL");
			return null;
		}
		
		if (isCancelled())
		{
			return null;
		}
		
		// Request auto-complete suggestions
		String requestResult = CFFunctions.httpGetAndroid(textView.getContext(), CFConstants.USER_AGENT, url);
		if ((requestResult == null) || (requestResult.length() <= 0))
		{
			return null;
		}
		
		if (isCancelled())
		{
			return null;
		}
		
		// Fill array with suggestions
		try
		{
			JSONArray results = new JSONArray(requestResult);
	        JSONArray suggestions = results.getJSONArray(1);
	        // JSONArray popularity = results.getJSONArray(2);  // Seems to always contain an array of "". Nothing to do with it.
	        
	        arrSuggestions = new String[suggestions.length()];
			for (int i = 0; i < suggestions.length(); i++)
			{
				arrSuggestions[i] = suggestions.getString(i);
			}

		}
		catch (Exception e)
		{
			return null;
		}
		
		return null;
	}
}
