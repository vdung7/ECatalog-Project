package net.mz.callflakessdk.core;





import net.mz.callflakessdk.R;
import net.mz.callflakessdk.libcfint.CFLib;
import android.app.Activity;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import com.localytics.android.LocalyticsSession;


/**
 * Activity to display the PostCallManager SDK User Accept screen.
 * </br>
 * Displayed only once, when your app is launched for the first time.
 * <p>
 * Note: this is not a public API.
 */
public class ActivityWelcome extends Activity
{
	private PostCallManager postCallManager;

	private LocalyticsSession localyticsSession;
	
	private Button btnOkay;
	private Button btnNoThanks;
	private TextView txtTOS;

	// Okay button click listener
	private OnClickListener clickListenerOkay = new OnClickListener()
	{

		public void onClick(View v)
		{
			postCallManager.setEnablePostCallScreen(true);
			localyticsSession.tagEvent("Accept EULA - " + postCallManager.getAppName());
			finish();
		};
	};

	// No Thanks button click listener
	private OnClickListener clickListenerNoThanks = new OnClickListener()
	{

		public void onClick(View v)
		{
			postCallManager.setEnablePostCallScreen(false);
			localyticsSession.tagEvent("Decline EULA - " + postCallManager.getAppName());
			finish();
		};
	};

	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		setContentView(R.layout.activity_welcome);

		
		
		// Initialize PostCallManager
		postCallManager = new PostCallManager(this);

		// Analytics
	    this.localyticsSession = CFLib.getLocalyticsSessionStartApp(this);
	    this.localyticsSession.open();
	    this.localyticsSession.upload();
	    
		txtTOS = (TextView) findViewById(R.id.txtTOS);
		txtTOS.setText(Html.fromHtml(getString(R.string.strTOS)));
		
		// Set button events
		btnOkay = (Button) findViewById(R.id.btnOkay);
		if (btnOkay != null)
		{
			btnOkay.setOnClickListener(clickListenerOkay);
		}

		btnNoThanks = (Button) findViewById(R.id.btnNoThanks);
		if (btnNoThanks != null)
		{
			btnNoThanks.setOnClickListener(clickListenerNoThanks);
		}

	
	}
	
	
	@Override
	protected void onResume()
	{
		super.onResume();
		
		this.localyticsSession.open();
	}
	
	
	@Override
	protected void onPause()
	{
		this.localyticsSession.close();
	    this.localyticsSession.upload();

		super.onPause();
	}
}
