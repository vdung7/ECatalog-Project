package net.mz.callflakessdk.core;


public interface EmailSelectListener
{
	public void onEmailSelected(String emailAddress);
}
