package net.mz.callflakessdk.core;


import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.AutoCompleteTextView;


/**
 * Used for detecting clicks on the Web Search drawableLeft.
 * <p>
 * Note: this is not a public API.
 */
public abstract class DrawableOnTouchListener implements OnTouchListener
{

	Drawable drawable;
	final int border = 10;


    /**
     * DrawableOnTouchListener constructor.
     * 
     * @param view AutoCompleteTextView containing a drawableLeft.
     *  
     */
	public DrawableOnTouchListener(AutoCompleteTextView view)
	{
		super();
		
		// Get AutoCompleteTextView compound drawables.
		final Drawable[] drawables = view.getCompoundDrawables();
		if (drawables != null && drawables.length == 4)
		{
			// Retain the first drawable, which is drawableLeft
			this.drawable = drawables[0];
		}
	}


	@Override
	public boolean onTouch(final View v, final MotionEvent event)
	{
		CFFunctions.logD(CFConstants.TAG, "LeftDrawableOnTOuchListener.onTouch -> Event detected");
		CFFunctions.logD(CFConstants.TAG, "LeftDrawableOnTOuchListener.onTouch -> Drawable: " + drawable);
		
		// If click event is finished and we previously obtained a drawableLeft...
		if ((event.getAction() == MotionEvent.ACTION_UP) && (drawable != null))
		{
			// Get click coordinates
			final int x = (int) event.getX();
			final int y = (int) event.getY();
			// Get drawableLeft bounds. Add a border to expand the touch area.
			final Rect bounds = drawable.getBounds();
			bounds.set(bounds.left, bounds.top, bounds.right + border, bounds.bottom + border);

			CFFunctions.logD(CFConstants.TAG, "LeftDrawableOnTOuchListener.onTouch -> Checking bounds");
			// Check if the drawableLeft's bounds contain the clicked coordinates, and fire the event.
			if (bounds.contains(x, y))
			{
				CFFunctions.logD(CFConstants.TAG, "LeftDrawableOnTOuchListener.onTouch -> Bounds OK, triggering onDrawableTouch");
				return onDrawableTouch(event);
			}
		}
		return false;
	}


	// Event triggered when drawableLeft is clicked
	public abstract boolean onDrawableTouch(final MotionEvent event);
}
