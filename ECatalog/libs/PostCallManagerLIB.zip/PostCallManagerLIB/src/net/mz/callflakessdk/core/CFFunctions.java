package net.mz.callflakessdk.core;


import java.util.ArrayList;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import net.mz.callflakessdk.R;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.util.EntityUtils;

import android.app.Activity;
import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.http.AndroidHttpClient;
import android.os.IBinder;
import android.provider.Settings;
import android.util.Log;
import android.view.inputmethod.InputMethodManager;


/**
 * Utility functions for the PostCallManager SDK.
 * <p>
 * Note: This is not a public API.
 */
final class CFFunctions
{
    /**
     * Launches a Google Web Search using the provided search query.
     * 
     * @param context The context used to access resources on behalf of the app. Cannot be null.
     * @param query Search query.
     * 
     * @return true - search launched successfully
     * </br>
     * 		   false - no activity found to handle this action 
     */
	public static boolean launchGoogleWebSearch(Context context, String query)
	{
		boolean result = false;
		
		Intent search = new Intent(Intent.ACTION_WEB_SEARCH);  
		search.putExtra(SearchManager.QUERY, query);  
		
		PackageManager pm = context.getPackageManager();
		if (pm.resolveActivity(search, 0) != null)
		{
			result = true;
			search.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
			context.startActivity(search);
		}
		else
		{
			CFFunctions.logD(CFConstants.TAG, "Could not resolve browser activity");
		}
		
		return result;
	}
	

    /**
     * Creates an event in the calendar.
     * 
     * @param context The context used to access resources on behalf of the app. Cannot be null.
     * @param title Event title.
     * @param timeBegin Beginning time of the event.
     * @param timeEnd End time of the event.
     * 
     * @return true - event created successfully
     * </br>
     * 		   false - no activity found to handle this action 
     */
	public static boolean setCalendarEvent(Context context, String title, long timeBegin, long timeEnd)
	{
		boolean result = false;
		
		if (context == null)
		{
			return result;
		}

		try
		{
			Intent intent = new Intent(Intent.ACTION_EDIT);
			intent.setType("vnd.android.cursor.item/event");
			intent.putExtra("title", title);
			// intent.putExtra("description", "Some description");
			intent.putExtra("beginTime", timeBegin);
			intent.putExtra("endTime", timeEnd);

			PackageManager pm = context.getPackageManager();
			if (pm.resolveActivity(intent, 0) != null)
			{
				result = true;
				intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
				context.startActivity(intent);
			}
			else
			{
				CFFunctions.logD(CFConstants.TAG, "Could not resolve calendar activity");
			}
		}
		catch (Exception e)
		{
			result = false;
			e.printStackTrace();
		}
		
		return result;
	}
	
	
    /**
     * Launches the email client for sending an email.
     * 
     * @param context The context used to access resources on behalf of the app. Cannot be null.
     * @param subject Email subject.
     * @param emailAddress Recipient's email address.
     * @param emailBody Email message body.
     * 
     * @return true - event created successfully
     * </br>
     * 		   false - no activity found to handle this action 
     */
	public static boolean sendEmail(Activity context, String subject, String emailAddress, String emailBody)
	{
		boolean result = false;
		
		if (context == null)
		{
			return result;
		}

		try
		{
			Intent intent = new Intent(Intent.ACTION_SENDTO);
			if(emailAddress!=null)
			{
			intent.setData(Uri.parse("mailto:" + emailAddress));
			}
			else
			{
				intent.setData(Uri.parse("mailto:" + ""));
			}
			//intent.setType("plain/text");  // If this doesn't work, try "message/rfc822"
			intent.putExtra(Intent.EXTRA_SUBJECT, subject);
//			if (emailAddress != null)
//			{
//				intent.putExtra(Intent.EXTRA_EMAIL, new String[] { emailAddress });
//			}
			if (emailBody != null)
			{
				intent.putExtra(Intent.EXTRA_TEXT, emailBody);
			}

			PackageManager pm = context.getPackageManager();
			if (pm.resolveActivity(intent, 0) != null)
			{
				result = true;
				intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
				context.startActivityForResult(Intent.createChooser(intent, context.getResources().getString(R.string.btnEmail)), CFConstants.REQUEST_CODE_SEND_EMAIL);
			}
			else
			{
				CFFunctions.logD(CFConstants.TAG, "Could not resolve email activity");
			}
		}
		catch (Exception e)
		{
			result = false;
			e.printStackTrace();
		}
		
		return result;
	}
	

    /**
     * Hides the virtual keyboard.
     * 
     * @param context The context used to access resources on behalf of the app. Cannot be null.
     * @param view View used to identify the current window.
     * 
     */
	public static void hideSoftKeyboard(Context context, IBinder iBinder)
	{
		try
		{
			if ((context == null) || (iBinder == null))
			{
				return;
			}
			
			InputMethodManager im = (InputMethodManager) context.getApplicationContext().getSystemService(Context.INPUT_METHOD_SERVICE);
			im.hideSoftInputFromWindow(iBinder, InputMethodManager.HIDE_NOT_ALWAYS);
		}
		catch (Exception e)
		{
		}
	}

    /**
     * Checks if the device has an active network connection.
     * 
     * @param context The context used to access resources on behalf of the app. Cannot be null.
     * 
     * @return true - an active network connection exists
     * </br>
     * 		   false - no active network connection
     * 
     */
	public static boolean isInternetConnected(Context context)
	{
		if (context == null)
		{
			return false;
		}
		
		NetworkInfo netInfo = (NetworkInfo) ((ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();

		if (netInfo == null || !netInfo.isConnected())
		{
			return false;
		}
		// Special handling for roaming, if ever needed. For now it's not the case.
		if (netInfo.isRoaming())
		{
			return true;
		}
		
		return true;
	}


    /**
     * Performs a HTTP GET request using AndroidHttpClient.
     * 
     * @param context The context used to access resources on behalf of the app. Cannot be null.
     * @param userAgent User Agent string used to identify the client.
     * @param url URL on which to perform the GET request.
     * 
     * @return Server response string. 
     * 
     */
	public static String httpGetAndroid(Context context, String userAgent, String url)
	{
		if ((context == null) || (url == null) || (url.length() <= 0))
		{
			CFFunctions.logD(CFConstants.TAG, "httpGetAndroid -> (context == null): " + (context == null));
			CFFunctions.logD(CFConstants.TAG, "httpGetAndroid -> (url == null): " + (url == null));
			CFFunctions.logD(CFConstants.TAG, "httpGetAndroid -> url: " + url);
			return null;
		}

		CFFunctions.logD(CFConstants.TAG, "httpGetAndroid -> Request: " + url);

		String result = null;
		HttpGet httpGet = null;

		AndroidHttpClient httpClientAndroid = AndroidHttpClient.newInstance(userAgent);
		try
		{
			httpGet = new HttpGet(url);
			
			HttpResponse response = httpClientAndroid.execute(httpGet);
			if (response != null)
			{
				result = EntityUtils.toString(response.getEntity());
				
				CFFunctions.logD(CFConstants.TAG, "httpGetAndroid -> Request result:\n" + result);				
			}

			if ((httpClientAndroid != null) && (httpClientAndroid.getConnectionManager() != null))
			{
				httpClientAndroid.getConnectionManager().closeExpiredConnections();
				httpClientAndroid.getConnectionManager().closeIdleConnections(30, TimeUnit.SECONDS);
			}
		}
		catch (Exception e)
		{
			if ((httpClientAndroid != null) && (httpClientAndroid.getConnectionManager() != null))
			{
				httpClientAndroid.getConnectionManager().closeExpiredConnections();
				httpClientAndroid.getConnectionManager().closeIdleConnections(30, TimeUnit.SECONDS);
			}

			result = e.getMessage();
			e.printStackTrace();
		}
		httpClientAndroid.close();

		return result;
	}


    /**
     * Returns a list of {@link android.provider.Settings.Secure#ANDROID_ID} known to have issues - they are not unique across devices.
     * @see <a href="http://code.google.com/p/android/issues/detail?id=10603">http://code.google.com/p/android/issues/detail?id=10603</a>
     * 
     * @return An ArrayList of String containing ANRDOID_IDs. 
     * 
     */
	private static ArrayList<String> getWrongAndroidDevices()
	{
		ArrayList<String> wrongDevices = new ArrayList<String>();
		wrongDevices.add("9774d56d682e549c");
		
		return wrongDevices;
	}


    /**
     * Returns a device ID. It attempts to use {@link android.provider.Settings.Secure#ANDROID_ID}.
     * </br>
     * If that fails, a random UUID is generated. This should be stored and used when needed. Otherwise, subsequent calls to this function will result in different device IDs.   
     * 
     * @param context The context used to access resources on behalf of the app. Cannot be null.
     * 
     * @return String containing a device ID.  
     * 
     */
	public static String getDeviceUUID(Context context)
	{
		if (context != null)
		{
			/*
			// Commented because they don't want us to get IMEI...
			try
			{
				// final String deviceId = ((TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE)).getDeviceId();
				TelephonyManager tM = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
				final String deviceId = tM.getDeviceId();
				CFFunctions.logD(CFConstants.TAG, "ETFunctions.getDeviceUUID -> tM.getDeviceId(): " + tM.getDeviceId());
				if (null != deviceId)
				{
					return deviceId;
				}
			}
			catch (RuntimeException e)
			{
				e.printStackTrace();
			}
			*/
			
			// Get ANDROID_ID
			final String androidId = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
			// See http://code.google.com/p/android/issues/detail?id=10603
			try
			{
				if ((androidId != null) && (!getWrongAndroidDevices().contains(androidId)))
				{
					CFFunctions.logD(CFConstants.TAG, "ETFunctions.getDeviceUUID -> androidId: " + androidId);
					return androidId;
				}
			}
			catch (Exception e)
			{
			}
		}

		// Generate new, just in case ANDROID_ID is not OK
		String deviceId = UUID.randomUUID().toString();
		CFFunctions.logD(CFConstants.TAG, "ETFunctions.getDeviceUUID -> Generated deviceId: " + deviceId);
		return deviceId;
	}


    /**
     * Used for writing log messages to LogCat.
     * 
     * @param tag Log message tag.
     * @param logMsg Log message.  
     * 
     */
	public static void logD(String tag, String logMsg)
	{
		if (CFConstants.LOGGING_ENABLED)
		{
			if (logMsg.length() > 4000)
			{
				Log.d(tag, logMsg.substring(0, 4000));
				logD(tag, logMsg.substring(4000));
			}
			else
			{
				Log.d(tag, logMsg);
			}
		}
	}
}
