package net.mz.callflakessdk.core;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.telephony.TelephonyManager;


/**
 * Broadcast Receiver used for detecting phone state.
 * You must declare this Broadcast Receiver in your app's AndroidManifest.xml file.
 * <p>
 * Note: this is not a public API.
 */
public class ReceiverCall extends BroadcastReceiver
{
	public static String lastPhoneNumber = null;  // Used for passing phone number to termination screen
	
	
	@Override
	public void onReceive(final Context context, Intent intent)
	{
		final Bundle extras = intent.getExtras();
		CFFunctions.logD(CFConstants.TAG, "ReceiverCall.onReceive -> intent.getAction(): " + intent.getAction());
				
		String phoneNumber = null;
		
		// Need to have extras to do our work
		if (extras != null)
		{
			// Get outgoing call phone number
			if (intent.getAction().equalsIgnoreCase("android.intent.action.NEW_OUTGOING_CALL"))
			{
				if (extras.containsKey(Intent.EXTRA_PHONE_NUMBER))
				{
					startBannerCachingService(context);
					
					phoneNumber = extras.getString(Intent.EXTRA_PHONE_NUMBER);
					CFFunctions.logD(CFConstants.TAG, "ReceiverCall.onReceive -> Outgoing phone number: " + phoneNumber);
				}
			}

			// Get incoming call phone number
			if (intent.getAction().equalsIgnoreCase("android.intent.action.PHONE_STATE"))
			{
				CFFunctions.logD(CFConstants.TAG, "ReceiverCall.onReceive -> state: " + extras.getString(TelephonyManager.EXTRA_STATE));
				if (extras.containsKey(TelephonyManager.EXTRA_INCOMING_NUMBER))
				{
					startBannerCachingService(context);

					phoneNumber = extras.getString(TelephonyManager.EXTRA_INCOMING_NUMBER);
					CFFunctions.logD(CFConstants.TAG, "ReceiverCall.onReceive -> Incoming phone number: " + phoneNumber);
				}
			}

			// Keep phone number
			if ((phoneNumber != null) && (lastPhoneNumber == null))
			{
				lastPhoneNumber = phoneNumber;
			}

			// Get phone state
			String state = null;
			if (extras.containsKey(TelephonyManager.EXTRA_STATE))
			{
				state = extras.getString(TelephonyManager.EXTRA_STATE);
			}

			// If phone state became IDLE, a call has ended. Display the Call Terminate screen.
			if ((state != null) && ((state.equals(TelephonyManager.CALL_STATE_IDLE) || (state.equals(TelephonyManager.EXTRA_STATE_IDLE)))))
			{
				CFFunctions.logD(CFConstants.TAG, "ReceiverCall.onReceive -> finishing ActivityCallTerminate");
				// Finish ActivityTerminate
				Intent lIntent = new Intent();
				lIntent.setAction(CFConstants.PHONE_CALL_FINISH_RECEIVER_NAME);
				lIntent.putExtra(CFConstants.INTENT_KEY_CALL_FINISHED, CFConstants.INTENT_ACTION_CALL_FINISHED);
				context.sendBroadcast(lIntent);

				CFFunctions.logD(CFConstants.TAG, "ReceiverCall.onReceive -> Showing call termination screen, lastPhoneNumber: " + lastPhoneNumber);
				showCallTerminationScreen(context, lastPhoneNumber);
			}
		}
		else
		{
			CFFunctions.logD(CFConstants.TAG, "ReceiverCall.onReceive -> Extras NOT found");
		}
	}


    /**
     * Determines if the Call Terminate screen can appear, depending on configuration made when toggling the On/Off button
     *
     * @param postCallManager PostCallManager object which contains the settings
     * 
     * @return true - Call Terminate screen can appear
     * </br>
     * 		   false - Call Terminate screen cannot appear 
     */
	private boolean canCallTerminationScreenAppear(PostCallManager postCallManager)
	{
		if (!postCallManager.isEnablePostCallScreen())
		{
			return false;
		}
		
		return true;
	}

	
    /**
     * Displays the PostCallManager SDK Call Terminate screen
     * 
     * @param context The context used to access resources on behalf of the app. Cannot be null.
     * @param phoneNumber Contact's phone number. Will be used by ActivityCallTerminate to get and display information about the contact.
     * 
     * @return true - event created successfully
     * </br>
     * 		   false - no activity found to handle this action 
     */
	private void showCallTerminationScreen(final Context context, final String phoneNumber)
	{
		PostCallManager postCallManager = new PostCallManager(context);
		
		if (!canCallTerminationScreenAppear(postCallManager))
		{
			CFFunctions.logD(CFConstants.TAG, "ReceiverCall.showCallTerminationScreen -> Post Call screen cannot appear because of user constraints");
			return;
		}

		final PostCallManager cf = postCallManager;
		Handler callTerminationHandler = new Handler();
		Runnable startActivityCallTerminate = new Runnable()
		{
			@Override
			public void run()
			{
				// Prepare the screen
				cf.unlockScreen();
				cf.turnOnScreen();
				
				// Start ActivityCallTerminate
				Intent intentCallTerminate = new Intent(context, ActivityCallTerminate.class);
				intentCallTerminate.putExtra(CFConstants.INTENT_KEY_PHONE_NUMBER, phoneNumber);
				// intentCallTerminate.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
				intentCallTerminate.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
				context.startActivity(intentCallTerminate);
				
				lastPhoneNumber = null;
			}
		};

		callTerminationHandler.postDelayed(startActivityCallTerminate, 1000);
	}
	
	
	private void startBannerCachingService(Context context)
	{
		Intent intentService = new Intent(context, ServiceBannerCaching.class);
		intentService.putExtra(CFConstants.INTENT_BANNER_CACHING_SERVICE_ACTION, CFConstants.DOWNLOAD_STARTAPP_BANNER);
		context.startService(intentService);		
	}
}
