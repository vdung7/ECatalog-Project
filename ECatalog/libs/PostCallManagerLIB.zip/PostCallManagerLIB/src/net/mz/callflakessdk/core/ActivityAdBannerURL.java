package net.mz.callflakessdk.core;

import net.mz.callflakessdk.R;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Window;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;


public class ActivityAdBannerURL extends Activity
{
	private WebView wvAppWall = null;
	private ProgressDialog dialogLoadingProgress = null;
	
	private String url;
	private boolean isRedirect = false; 
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_ads);
		
		if (getIntent().hasExtra(CFConstants.INTENT_KEY_BANNER_URL))
		{
			url = getIntent().getStringExtra(CFConstants.INTENT_KEY_BANNER_URL);
		}

		if (getIntent().hasExtra(CFConstants.INTENT_KEY_BANNER_REDIRECT))
		{
			isRedirect = getIntent().getBooleanExtra(CFConstants.INTENT_KEY_BANNER_REDIRECT, false);
		}
		
		if ((url == null) || (url.compareTo("") == 0))
		{
			finish();
		}

		// Find views
		wvAppWall = (WebView) findViewById(R.id.wvAppWall);
	}
	
	@Override
	protected void onStart()
	{
		super.onStart();		
	}
	
	
	@Override
	protected void onStop()
	{
		super.onStop();
	}
	
	
	@Override
	protected void onResume()
	{
		super.onResume();
		
		// Create a WebView and configure it
		WebSettings settings = wvAppWall.getSettings();
		settings.setJavaScriptEnabled(true);
		settings.setPluginsEnabled(true);
		settings.setBuiltInZoomControls(true);
		wvAppWall.setScrollBarStyle(WebView.SCROLLBARS_OUTSIDE_OVERLAY);
		
		// Display a "Loading..." ProgressDialog 
		showLoadingDialog();
		
		wvAppWall.setWebViewClient(new WebViewClient()
		{

			public boolean shouldOverrideUrlLoading(WebView view, String url)
			{
				
//
//				String lowerUrl = url.toLowerCase();
//
//				boolean isMarketLink = lowerUrl.startsWith("market") || lowerUrl.startsWith("http://play.google.com") || lowerUrl.startsWith("https://play.google.com");
//				     
//				if (!isMarketLink) {
//				      return false;
//				}
//
//				Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(url));
//				intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS | Intent.FLAG_ACTIVITY_NEW_TASK);
//				ActivityAdBannerURL.this.startActivity(intent);
//				
//				return true;
				
				String lowerUrl = url.toLowerCase();
				
			    if (lowerUrl != null && lowerUrl.startsWith("market://") || lowerUrl.startsWith("http://play.google.com") || lowerUrl.startsWith("https://play.google.com")) {
			        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
			        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS | Intent.FLAG_ACTIVITY_NEW_TASK);
					view.getContext().startActivity(intent);
			        
			        // end current activity, otherwise the back button will not work correctly
			        view.destroy();
			        ActivityAdBannerURL.this.finish();
			        
			        return true;
			    } else {
			        return false;
			    }
			}


			public void onPageFinished(WebView view, String url)
			{
				CFFunctions.logD(CFConstants.TAG, "ActivityAdBannerURL.onPageFinished -> url: " + url);
				CFFunctions.logD(CFConstants.TAG, "ActivityAdBannerURL.onPageFinished -> isRedirect: " + isRedirect);
				
				try
				{
					hideLoadingDialog();
					
					if ((isRedirect) && ((url.toLowerCase().contains("market")) || (url.toLowerCase().contains("http://play.google.com")) || (url.toLowerCase().contains("https://play.google.com"))))
					{
						String finalUrl = url.substring(url.indexOf("link=") + 5, url.length());
						CFFunctions.logD(CFConstants.TAG, "ActivityAdBannerURL.onPageFinished -> url: " + finalUrl);

						if ((!url.toLowerCase().contains("market")) && (!url.toLowerCase().contains("http://play.google.com")) && (!url.toLowerCase().contains("https://play.google.com")))
						{
							return;
						}
						
						Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(finalUrl));
						intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
						 
						startActivity(intent);
						              
						if (view != null)
						{
							view.destroy();
						}
						              
						finish();
					}
				}
				catch (Exception e)
				{
				}				
			}


			public void onReceivedError(WebView view, int errorCode, String description, String failingUrl)
			{
				Toast.makeText(ActivityAdBannerURL.this, description, Toast.LENGTH_SHORT).show();
			}
		});

		// Create a PostCallManager instance to get device ID
		// PostCallManager postCallManager = new PostCallManager(this);
		// Launch URL in web browser
		wvAppWall.loadUrl(url);
	}
	
	
    /**
     * Creates and displays a standard {@link android.app#ProgressDialog} with the message "Loading..." 
     */
	public void showLoadingDialog()
	{
		if (dialogLoadingProgress != null)
		{
			return;
		}
		
		try
		{
			dialogLoadingProgress = ProgressDialog.show(this, "", getResources().getString(R.string.strLoading), false);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}


    /**
     * Hides the ProgressDialog created using {@link #showLoadingDialog() showLoadingDialog}
     */
	public void hideLoadingDialog()
	{
		try
		{
			if (dialogLoadingProgress != null)
			{
				dialogLoadingProgress.dismiss();
				dialogLoadingProgress = null;
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
}
