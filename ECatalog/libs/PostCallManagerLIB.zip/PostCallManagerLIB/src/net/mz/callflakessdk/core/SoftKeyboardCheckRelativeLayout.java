package net.mz.callflakessdk.core;

import net.mz.callflakessdk.R;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.RelativeLayout;

/**
 * When the keyboard is shown hide the upmost linear layout to allow the search bar to be visible
 * 
 * @author Dan
 *
 */
public class SoftKeyboardCheckRelativeLayout extends RelativeLayout {

    private int largestHeight;

    public SoftKeyboardCheckRelativeLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {

    	int proposedheight = MeasureSpec.getSize(heightMeasureSpec);
        largestHeight= Math.max(largestHeight, getHeight());
        	
        if (largestHeight > proposedheight) {
        	keyboardIsShown();
        } else {
        	keyboardIsHidden();
        }

        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

	private void keyboardIsShown() {
		// hide the top of the screen
		findViewById(R.id.rlUserInfo).setVisibility(View.GONE);
		// hide the ads
		findViewById(R.id.llAds).setVisibility(View.GONE);
	}

	private void keyboardIsHidden() {
		// show the top of the screen
		findViewById(R.id.rlUserInfo).setVisibility(View.VISIBLE);
		// show the ads
		findViewById(R.id.llAds).setVisibility(View.VISIBLE);
	}
}
