package net.mz.callflakessdk.core;


import net.mz.callflakessdk.libcfint.BannerDownloadListener;
import net.mz.callflakessdk.libcfint.CFLib;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Binder;
import android.os.IBinder;


public class ServiceBannerCaching extends Service implements BannerDownloadListener
{

	private final IBinder binder = new BannerCachingBinder();


	@Override
	public int onStartCommand(Intent intent, int flags, int startId)
	{
		if (intent != null && CFConstants.DOWNLOAD_STARTAPP_BANNER.compareTo(intent.getStringExtra(CFConstants.INTENT_BANNER_CACHING_SERVICE_ACTION)) == 0)
		{
			// Remove existing banner HTML from prefs
			Editor preferenceEditor = getSettings().edit();
			preferenceEditor.remove(CFConstants.PREF_KEY_STARTAPP_BANNER);
			preferenceEditor.commit();
			
			// CFLib.loadAdBannerStartApp(this, null, null, null, null, this);
			PostCallManager postCallManager = new PostCallManager(this);
			CFLib.loadAdBannerStartApp2(postCallManager.getAdBannerUrl(), this);
			
			return Service.START_STICKY;
		}
		else
		{
			return super.onStartCommand(intent, flags, startId);
		}
	}


	@Override
	public void onBannerDownloaded(final String bannerHtml)
	{
		// Save the banner HTML to prefs file
		Editor preferenceEditor = getSettings().edit();
		preferenceEditor.putString(CFConstants.PREF_KEY_STARTAPP_BANNER, bannerHtml);
		preferenceEditor.commit();
		
		this.stopSelf();
	}


	@Override
	public IBinder onBind(Intent intent)
	{
		return binder;
	}


	public class BannerCachingBinder extends Binder
	{

		ServiceBannerCaching getService()
		{
			return ServiceBannerCaching.this;
		}
	}
	
	
	private SharedPreferences getSettings()
	{
		return getSharedPreferences(CFConstants.PREFS_NAME_POSTCALLMANAGER_SDK, Context.MODE_PRIVATE);
	}
}
